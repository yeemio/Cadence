# Cadence 终测报告（166ce5d）

- 被测提交：`166ce5d6b1c0bf9cfad1882a154deb68d8228b07`（main，`git status` 干净；本轮**未改代码、未推送**）
- 测试时间：2026-10-27 09:32–09:45（Asia/Shanghai）
- 环境：box 本机 docker compose，project `cadence`，`--profile saas`；`docker compose build --build` 重建 server+migrate+web
- 变量：`SMES_TENANTS=default,tenant-a,tenant-b`；`MODULES_ENABLED`=29 模块全量；`SMES_DEFAULT_WAREHOUSE_CODE=MAIN`；**未设置** `SMES_DEFAULT_WAREHOUSE_ID` / `WAREHOUSE_ID`
- migrate 完成后 psql 核对三租户各一行 MAIN：`wh-seed-main` / `wh-seed-main-tenant-a` / `wh-seed-main-tenant-b`（`raw/main-wh.txt`）
- 夹具：seed 仅 default 账号 → SQL 复制 admin/viewer（a/b）与 approver/demo-admin（仅 a）（`scripts/fixture.sql`）
- 产物目录：`/workspace/retest-166ce5d/`（新建，未覆盖历轮）
- 栈状态：**保持运行**（pg/proxy/server/web healthy）；server 现 env 仍为 `SMES_PARTS_APPROVAL_LEVELS=3`（D-25 多级验后未回切）

## 收版结论：**可收版**

上轮（59c9f8d）三个 P1 阻断（D-21 / D-23 / D-24）本轮全部复测通过；O-1 大屏路由迁至 `/bigscreen/*` 并通过直接打开+刷新 200 HTML；D-25 多级审批经 env 装配验证链序/中途驳回/跨租户，缺省单级零回归；图文档五新面（P0/P1-a/b/c/e）首测双租户 26/26。

**无新增 P0/P1 阻断缺陷。**

非阻断备注：
- **D-18**：三租户日统计仍 `{"rows":[]}`（形状 200 通过）。本轮 rebuild 后尚未再等到北京时间 08:10 日批；数值对账留待日批后补一眼即可，不挡收版。
- **D-22（P3，历轮已知）**：报表中心仍无导出路由；本轮未重开为阻断。
- 主链脚本已知假阴（WO-09 / DP-05 互斥连带 / IN-08 / tenant-b AP-01 夹具 / D2-05 口令强度 / persona PX-03 测试干扰 / crawl `/scan`）与历轮一致，**非产品缺陷**。

---

## 一、缺陷复测

| 项 | 结论 | 关键数据 |
|---|---|---|
| **D-21** SSE `report:read` | **通过** | viewer/approver → **403**（文案含 `report:read`）；admin → 200 且帧与快照一致；无 token / 跨租户 → **401**。矩阵同口径。`logs/screen3.log` 35/35 |
| **O-1** `/bigscreen/digital-operation` | **通过** | 直接打开与深链刷新均 **200 text/html**（nginx 窄回落）；应用内导航+SSE 15s 内 4 帧、时钟刷新、「在制工作令」变化；1920×1080 截图 `shots/screen/screen-{t1,t2,direct}-1920.png` |
| **D-23** 派工转单 | **通过** | 零件派工 create→assign→start→transfer → **201 committed**（`dispatch-transferred`）；tenant-a/b 各过。不再出现「不支持转单写入」 |
| **D-24** 撤销判定 | **通过** | judge + concession 后 `revertJudgment` → **201 committed**（`revoked`）；订单回到 `pending`，concession `failedQty=0`，不合格 `voided`。双租户过。不再「未实现 revertJudgment」 |
| **D-25** 多级审批 | **通过** | 缺省单级 `6/6` 零回归；`SMES_PARTS_APPROVAL_LEVELS=3` + `LEVEL2/3_ROLE` 后：L1→level2_review→L2→level3_review→L3→approved；错级或签拒；中途驳回→rejected；跨租户拒。`13/13`（`logs/d25-*.log`） |
| D-17 两端点权限 | **通过** | 纳入 screen3；与 D-21 同口径 |
| D-18 日统计 | **通过（形状）** | 三租户 200 `{"rows":[]}`；日批未跑，数值未验 |
| D-19/D-20 | **通过** | 见 O-1；SSE 帧 kpi 对齐快照（default 0；a/b 各 5） |
| D-16 / D-15 / 报表中心 | **通过** | defects 套件 a/b 各 12/12；metrics 九口径；query 对账绿 |

---

## 二、图文档五新面首测（范围内）

范围：P0 呈现面 / P1-a 发布通知 / P1-b 路线互链 / P1-c 索引端点 / P1-e 签名引用。**P1-d 移动查看页、P2 水印不在本轮。**

| 面 | 结论 | 证据 |
|---|---|---|
| **P1-c 索引** | **通过** | `GET /drawing/drawings` 反映 PG 实态（含本轮发布图号）；viewer 403；无凭据 401；跨租户 token 空页/隔离（DI-*） |
| **P0 呈现/查看** | **通过** | revisions/view、view-audit、work-orders/:id/drawings；匿名与篡改见下 |
| **P1-a 发布通知** | **通过** | publish → `drawing-revision-published`；manager 待办标题「图纸 DWG-… 已发布新版本 v3，请确认生产使用版本」；`GET /drawing/notices/:id` 有 notice |
| **P1-b 路线互链** | **通过** | baseline routing 挂 drawingNo 后 `GET /baseline/routings/:drawingNo` 读回（PB-*） |
| **P1-e 签名引用** | **通过** | view 签发 `read-references` → 匿名 redeem **200**；篡改 token / 过期类 → **404**（DR-03/04）；跨租户不可兑现 |

双租户：`drawing-a/b` 各 **26/26**。矩阵已纳入 11 条 drawing 相关路由（含 `/drawing/read-references/:token`、`/baseline/routings/:drawingNo`）。

---

## 三、权限矩阵

- 路由再生：301 条（`raw/routes.json` / `raw/matrix-full.json`）
- 维度：3 租户 ×（admin/approver/viewer/demo-admin/noauth）+ 跨租户；tenant-b 无 approver/demo-admin 列为空
- **0 个 5xx**；无凭据非公开口一律 401；跨租户非公开 401；viewer 写方法 2xx = 0
- **D-21 已闭合**：`GET /screen/digital-operation/stream` 上 viewer/approver = **403**（不再 200）
- 图文档新路由：admin 可达（空载荷 400/假 id 404 按设计）；approver/viewer 403；`read-references` 假 token 404（匿名可打，凭据无效）
- 分析：`logs/matrix-analysis.txt`

---

## 四、回归

| 项 | 结论 | 数据 |
|---|---|---|
| D-8/D-9 主链 | 通过（脚本已知假阴） | a 60/66、b 59/66；失败项与历轮同因 |
| D-2 / D-4 | 通过 | 18/19（D2-05 口令强度已知） |
| D-14 | 通过 | 收货/预占耗用/直接领用 201；最终 onHand 6、reserved 4、available 2 |
| 移动端 | 通过 | viewer+admin 共 32 页次；0 卡加载、0×403、0 控制台错；`/m/scan` 为未注册路由页（产品文案「页面不存在」） |
| UI 爬取 | 125/127 | 仅 admin/demo-admin `/scan` 爬虫超时（历轮同） |
| persona | 48/49 | PX-03 为测试自干扰待办（历轮同） |
| **D-1 双重启（最后单独）** | **通过** | r1：`tenant-a,tenant-b,default` ALL200；r2：`default,tenant-b,tenant-a` ALL200；越界租户事件 **0**；`event_records` 重启前后均为 **268**（无丢无增） |

---

## 五、新缺陷

本轮**无新增 P0/P1**。  
遗留非阻断：D-18 日批空行（待 08:10 后补验数值）、D-22 导出缺失（P3）。

---

## 六、数字摘要

| 指标 | 值 |
|---|---|
| 提交全文哈希 | `166ce5d6b1c0bf9cfad1882a154deb68d8228b07` |
| 模块数 | 29 |
| MAIN 仓 | 3/3 租户 |
| screen3 | 35/35 |
| defects a/b | 12/12 ×2 |
| drawing a/b | 26/26 ×2 |
| D-25 single / multi | 6/6 · 13/13 |
| matrix | 301 路由 · 0×5xx |
| D-1 | 2×ALL200 · orphan 0 · events 268→268 |
| 收版 | **可收版** |
| 文件夹 | `/workspace/retest-166ce5d/` |

## 七、附件索引

- 报告：`Cadence-final-166ce5d-report.md`（本文件）
- 用例表：`cases.md`
- 日志：`logs/`
- 原始 JSON/SQL：`raw/`
- 截图：`shots/screen/`
- 脚本：`scripts/`
