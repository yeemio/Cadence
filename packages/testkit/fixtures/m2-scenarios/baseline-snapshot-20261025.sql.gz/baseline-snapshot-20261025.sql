--
-- PostgreSQL database dump
--

\restrict 65iKXXDdpTlchJRqb024dSjCNbDS13xixoVhD2nCQBVQrgpwZvLhXO9BcjznRZh

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 16.15 (Debian 16.15-1.pgdg13+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: business_store_forbid_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.business_store_forbid_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  RAISE EXCEPTION 'append-only table % blocked: % is not allowed (use supersedes chain)', TG_TABLE_NAME, TG_OP
    USING ERRCODE = 'check_violation';
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: approval_cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_cases (
    id text NOT NULL,
    tenant_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    subject_type text NOT NULL,
    subject_id text NOT NULL,
    submitter_id text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.approval_cases FORCE ROW LEVEL SECURITY;


--
-- Name: approval_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.approval_events FORCE ROW LEVEL SECURITY;


--
-- Name: approval_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.approval_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: approval_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.approval_events_seq_seq OWNED BY public.approval_events.seq;


--
-- Name: approval_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.approval_records (
    id text NOT NULL,
    tenant_id text NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    reviewer_id text NOT NULL,
    decision text NOT NULL,
    reason text NOT NULL,
    evidence jsonb NOT NULL,
    object_version integer NOT NULL,
    decided_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.approval_records FORCE ROW LEVEL SECURITY;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    user_id text,
    method text NOT NULL,
    path text NOT NULL,
    summary text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.audit_logs FORCE ROW LEVEL SECURITY;


--
-- Name: baseline_command_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.baseline_command_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL,
    claimed_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.baseline_command_operations FORCE ROW LEVEL SECURITY;


--
-- Name: cost_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_entries (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    work_order_id text NOT NULL,
    category text NOT NULL,
    amount_minor integer,
    quantity double precision,
    trade text,
    source_type text NOT NULL,
    source_ref_id text NOT NULL,
    source_key text NOT NULL,
    delta_of text,
    work_date text,
    remark text,
    occurred_at timestamp(6) with time zone NOT NULL,
    recorded_by text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.cost_entries FORCE ROW LEVEL SECURITY;


--
-- Name: cost_entries_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cost_entries_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cost_entries_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cost_entries_seq_seq OWNED BY public.cost_entries.seq;


--
-- Name: cost_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cost_snapshots (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    model_code text NOT NULL,
    model_version integer NOT NULL,
    totals jsonb NOT NULL,
    rebuilt_by text NOT NULL,
    rebuilt_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.cost_snapshots FORCE ROW LEVEL SECURITY;


--
-- Name: costing_models; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.costing_models (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text,
    definition jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.costing_models FORCE ROW LEVEL SECURITY;


--
-- Name: costing_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.costing_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.costing_operations FORCE ROW LEVEL SECURITY;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    contact text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.customers FORCE ROW LEVEL SECURITY;


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    parent_id text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.departments FORCE ROW LEVEL SECURITY;


--
-- Name: dispatch_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispatch_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.dispatch_events FORCE ROW LEVEL SECURITY;


--
-- Name: dispatch_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.dispatch_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dispatch_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.dispatch_events_seq_seq OWNED BY public.dispatch_events.seq;


--
-- Name: dispatch_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispatch_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.dispatch_operations FORCE ROW LEVEL SECURITY;


--
-- Name: dispatch_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispatch_orders (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text,
    kind text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    title text NOT NULL,
    drawing_no text,
    operation_code text,
    material text,
    size_spec text,
    quantity double precision NOT NULL,
    done_qty double precision DEFAULT 0 NOT NULL,
    assignee text,
    due_at timestamp(6) with time zone,
    remark text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.dispatch_orders FORCE ROW LEVEL SECURITY;


--
-- Name: drawing_change_notices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drawing_change_notices (
    id text NOT NULL,
    tenant_id text NOT NULL,
    drawing_id text NOT NULL,
    from_version integer NOT NULL,
    to_version integer NOT NULL,
    change_note text NOT NULL,
    published_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.drawing_change_notices FORCE ROW LEVEL SECURITY;


--
-- Name: drawing_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drawing_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.drawing_operations FORCE ROW LEVEL SECURITY;


--
-- Name: drawing_revisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drawing_revisions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    drawing_id text NOT NULL,
    version integer NOT NULL,
    file_ref text NOT NULL,
    change_note text NOT NULL,
    classification text NOT NULL,
    changed_by text NOT NULL,
    changed_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.drawing_revisions FORCE ROW LEVEL SECURITY;


--
-- Name: drawing_view_trails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.drawing_view_trails (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    drawing_id text NOT NULL,
    version integer NOT NULL,
    viewed_by text NOT NULL,
    viewed_at timestamp(6) with time zone NOT NULL,
    classification text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.drawing_view_trails FORCE ROW LEVEL SECURITY;


--
-- Name: drawing_view_trails_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.drawing_view_trails_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: drawing_view_trails_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.drawing_view_trails_seq_seq OWNED BY public.drawing_view_trails.seq;


--
-- Name: earnings_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.earnings_records (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    person_id text NOT NULL,
    period_key text NOT NULL,
    rule_id text NOT NULL,
    rule_version integer NOT NULL,
    basis text NOT NULL,
    labor_kind text NOT NULL,
    quantity double precision NOT NULL,
    rate_minor integer NOT NULL,
    coefficient double precision NOT NULL,
    amount_minor integer NOT NULL,
    pay_run_id text NOT NULL,
    source_refs jsonb NOT NULL,
    source_key text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    recorded_by text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.earnings_records FORCE ROW LEVEL SECURITY;


--
-- Name: earnings_records_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.earnings_records_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: earnings_records_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.earnings_records_seq_seq OWNED BY public.earnings_records.seq;


--
-- Name: equipment_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment_records (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text,
    location text,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.equipment_records FORCE ROW LEVEL SECURITY;


--
-- Name: event_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_records (
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    provenance jsonb,
    payload jsonb NOT NULL,
    CONSTRAINT event_records_aggregate_revision_check CHECK ((aggregate_revision >= 1))
);

ALTER TABLE ONLY public.event_records FORCE ROW LEVEL SECURITY;


--
-- Name: fault_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fault_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.fault_events FORCE ROW LEVEL SECURITY;


--
-- Name: fault_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.fault_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: fault_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.fault_events_seq_seq OWNED BY public.fault_events.seq;


--
-- Name: fault_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.fault_reports (
    id text NOT NULL,
    tenant_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    equipment_code text NOT NULL,
    description text NOT NULL,
    reported_by text NOT NULL,
    assignee text,
    assigned_at timestamp(6) with time zone,
    resolution_remark text,
    resolved_by text,
    resolved_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.fault_reports FORCE ROW LEVEL SECURITY;


--
-- Name: gap_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.gap_checks (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    seq bigint NOT NULL,
    kinds jsonb NOT NULL,
    gap_lines jsonb NOT NULL,
    complete boolean NOT NULL,
    checked_by text NOT NULL,
    checked_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.gap_checks FORCE ROW LEVEL SECURITY;


--
-- Name: gap_checks_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.gap_checks_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: gap_checks_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.gap_checks_seq_seq OWNED BY public.gap_checks.seq;


--
-- Name: hours_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hours_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.hours_operations FORCE ROW LEVEL SECURITY;


--
-- Name: inspection_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.inspection_events FORCE ROW LEVEL SECURITY;


--
-- Name: inspection_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inspection_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inspection_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inspection_events_seq_seq OWNED BY public.inspection_events.seq;


--
-- Name: inspection_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspection_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.inspection_operations FORCE ROW LEVEL SECURITY;


--
-- Name: inspections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inspections (
    id text NOT NULL,
    tenant_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    kind text NOT NULL,
    source_type text,
    source_ref_id text,
    item_id text,
    drawing_no text,
    quantity double precision NOT NULL,
    passed_qty double precision,
    failed_qty double precision,
    judge_remark text,
    judged_by text,
    judged_at timestamp(6) with time zone,
    close_due_at timestamp(6) with time zone,
    overdue_notified_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.inspections FORCE ROW LEVEL SECURITY;


--
-- Name: inventory_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.inventory_events FORCE ROW LEVEL SECURITY;


--
-- Name: inventory_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.inventory_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: inventory_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.inventory_events_seq_seq OWNED BY public.inventory_events.seq;


--
-- Name: inventory_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.inventory_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.inventory_operations FORCE ROW LEVEL SECURITY;


--
-- Name: items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.items (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    spec text,
    unit text,
    category text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.items FORCE ROW LEVEL SECURITY;


--
-- Name: kit_checks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kit_checks (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    seq bigint NOT NULL,
    kinds jsonb NOT NULL,
    gap_lines jsonb NOT NULL,
    complete boolean NOT NULL,
    refreshed_by text NOT NULL,
    refreshed_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.kit_checks FORCE ROW LEVEL SECURITY;


--
-- Name: kit_checks_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.kit_checks_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kit_checks_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.kit_checks_seq_seq OWNED BY public.kit_checks.seq;


--
-- Name: labor_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_entries (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    worker_id text NOT NULL,
    work_date text NOT NULL,
    trade text NOT NULL,
    process_code text,
    hours double precision NOT NULL,
    output_qty double precision,
    direction text NOT NULL,
    source_report_id text NOT NULL,
    reverses text,
    work_order_id text,
    drawing_no text,
    dispatch_id text,
    source_key text NOT NULL,
    remark text,
    occurred_at timestamp(6) with time zone NOT NULL,
    recorded_by text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.labor_entries FORCE ROW LEVEL SECURITY;


--
-- Name: labor_entries_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.labor_entries_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: labor_entries_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.labor_entries_seq_seq OWNED BY public.labor_entries.seq;


--
-- Name: labor_ledger_months; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.labor_ledger_months (
    id text NOT NULL,
    tenant_id text NOT NULL,
    worker_id text NOT NULL,
    month text NOT NULL,
    trade text NOT NULL,
    total_hours double precision NOT NULL,
    output_qty double precision NOT NULL,
    entry_count integer NOT NULL,
    first_work_date text,
    last_work_date text,
    rebuilt_by text NOT NULL,
    rebuilt_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.labor_ledger_months FORCE ROW LEVEL SECURITY;


--
-- Name: listing_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.listing_events FORCE ROW LEVEL SECURITY;


--
-- Name: listing_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.listing_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: listing_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.listing_events_seq_seq OWNED BY public.listing_events.seq;


--
-- Name: listing_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_lines (
    id text NOT NULL,
    tenant_id text NOT NULL,
    sheet_id text NOT NULL,
    work_order_id text NOT NULL,
    kind text NOT NULL,
    line_no integer NOT NULL,
    drawing_no text,
    code text,
    name text,
    spec text,
    item_id text,
    required_qty double precision NOT NULL,
    needed_by timestamp(6) with time zone,
    validation_status text NOT NULL,
    candidate_item_id text,
    candidate_item_code text,
    similarity double precision DEFAULT 0 NOT NULL,
    basis text,
    source text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.listing_lines FORCE ROW LEVEL SECURITY;


--
-- Name: listing_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.listing_operations FORCE ROW LEVEL SECURITY;


--
-- Name: listing_sheets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.listing_sheets (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    kind text NOT NULL,
    name text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.listing_sheets FORCE ROW LEVEL SECURITY;


--
-- Name: maintenance_activities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_activities (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    kind text NOT NULL,
    resource_ref text NOT NULL,
    plan_id text,
    plan_version integer,
    task_id text,
    checkpoint_id text,
    result text,
    actions_done jsonb,
    fault_ref text,
    restored boolean,
    performed_by text NOT NULL,
    performed_at timestamp(6) with time zone NOT NULL,
    note text,
    occurred_at timestamp(6) with time zone NOT NULL,
    recorded_by text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.maintenance_activities FORCE ROW LEVEL SECURITY;


--
-- Name: maintenance_activities_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.maintenance_activities_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: maintenance_activities_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.maintenance_activities_seq_seq OWNED BY public.maintenance_activities.seq;


--
-- Name: maintenance_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.maintenance_operations FORCE ROW LEVEL SECURITY;


--
-- Name: maintenance_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_plans (
    id text NOT NULL,
    tenant_id text NOT NULL,
    plan_id text NOT NULL,
    name text,
    resource_ref text NOT NULL,
    cycle jsonb NOT NULL,
    checkpoints jsonb NOT NULL,
    upkeep_actions jsonb NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.maintenance_plans FORCE ROW LEVEL SECURITY;


--
-- Name: maintenance_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.maintenance_tasks (
    id text NOT NULL,
    tenant_id text NOT NULL,
    flow_config_id text NOT NULL,
    source text NOT NULL,
    kind text NOT NULL,
    resource_ref text NOT NULL,
    fault_ref text,
    plan_id text,
    plan_version integer,
    due_key text,
    due_at timestamp(6) with time zone,
    assignee text,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    created_by text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    started_at timestamp(6) with time zone,
    completed_at timestamp(6) with time zone,
    cancelled_at timestamp(6) with time zone,
    cancel_reason text,
    source_key text
);

ALTER TABLE ONLY public.maintenance_tasks FORCE ROW LEVEL SECURITY;


--
-- Name: material_validation_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.material_validation_runs (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    issued_by text NOT NULL,
    summary jsonb NOT NULL,
    lines jsonb NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.material_validation_runs FORCE ROW LEVEL SECURITY;


--
-- Name: metric_pack_activations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metric_pack_activations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    pack_id text NOT NULL,
    pack_version integer NOT NULL,
    title text NOT NULL,
    pack jsonb NOT NULL,
    metric_refs jsonb NOT NULL,
    activated_by text NOT NULL,
    activated_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.metric_pack_activations FORCE ROW LEVEL SECURITY;


--
-- Name: metric_pack_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.metric_pack_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.metric_pack_operations FORCE ROW LEVEL SECURITY;


--
-- Name: nonconformities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.nonconformities (
    id text NOT NULL,
    tenant_id text NOT NULL,
    inspection_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    item_id text,
    quantity double precision NOT NULL,
    reason text,
    disposal text,
    dispose_remark text,
    disposed_by text,
    disposed_at timestamp(6) with time zone,
    close_remark text,
    closed_by text,
    closed_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.nonconformities FORCE ROW LEVEL SECURITY;


--
-- Name: outbox_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox_records (
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_attempt_at timestamp(6) with time zone,
    next_attempt_at timestamp(6) with time zone,
    delivered_at timestamp(6) with time zone
);

ALTER TABLE ONLY public.outbox_records FORCE ROW LEVEL SECURITY;


--
-- Name: outsourcing_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outsourcing_lines (
    id text NOT NULL,
    tenant_id text NOT NULL,
    dispatch_id text NOT NULL,
    line_no integer NOT NULL,
    process_code text NOT NULL,
    drawing_no text,
    supplier_ref text NOT NULL,
    supplier_name text,
    quantity double precision NOT NULL,
    unit_price_minor integer,
    price_source text,
    margin_permyriad integer,
    promised_at timestamp(6) with time zone,
    source_listing_line_id text,
    object_version integer DEFAULT 1 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.outsourcing_lines FORCE ROW LEVEL SECURITY;


--
-- Name: outsourcing_price_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outsourcing_price_rules (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text,
    process_code text NOT NULL,
    unit_price_minor integer NOT NULL,
    margin_permyriad integer NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.outsourcing_price_rules FORCE ROW LEVEL SECURITY;


--
-- Name: parts_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.parts_requests (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 2 NOT NULL,
    item_id text NOT NULL,
    quantity double precision NOT NULL,
    requester text NOT NULL,
    remark text,
    shipment_ref text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.parts_requests FORCE ROW LEVEL SECURITY;


--
-- Name: pay_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pay_runs (
    id text NOT NULL,
    tenant_id text NOT NULL,
    person_id text NOT NULL,
    period_key text NOT NULL,
    period_kind text DEFAULT 'month'::text NOT NULL,
    rule_versions jsonb NOT NULL,
    total_quantity double precision NOT NULL,
    total_amount_minor integer NOT NULL,
    line_count integer NOT NULL,
    computed_by text NOT NULL,
    computed_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.pay_runs FORCE ROW LEVEL SECURITY;


--
-- Name: payroll_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_operations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command_kind text NOT NULL
);

ALTER TABLE ONLY public.payroll_operations FORCE ROW LEVEL SECURITY;


--
-- Name: payroll_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_rules (
    id text NOT NULL,
    tenant_id text NOT NULL,
    rule_id text NOT NULL,
    name text,
    basis text DEFAULT 'hours'::text NOT NULL,
    rate_minor integer NOT NULL,
    coefficient double precision DEFAULT 1 NOT NULL,
    scope jsonb NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    supersedes text,
    audit_status text NOT NULL,
    provenance jsonb,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.payroll_rules FORCE ROW LEVEL SECURITY;


--
-- Name: policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.policies (
    rule_key text NOT NULL,
    tenant_id text NOT NULL,
    kind text NOT NULL,
    user_id text,
    role text,
    resource text,
    action text
);

ALTER TABLE ONLY public.policies FORCE ROW LEVEL SECURITY;


--
-- Name: positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.positions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    department_ref text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.positions FORCE ROW LEVEL SECURITY;


--
-- Name: process_defs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.process_defs (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    category text,
    description text,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.process_defs FORCE ROW LEVEL SECURITY;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_orders (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 2 NOT NULL,
    supplier_ref text,
    supplier_name text,
    promised_at timestamp(6) with time zone NOT NULL,
    lines jsonb NOT NULL,
    request_ids jsonb NOT NULL,
    buyer text,
    remark text,
    receipt_ref text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.purchase_orders FORCE ROW LEVEL SECURITY;


--
-- Name: purchase_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_requests (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text,
    kind text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    item_id text NOT NULL,
    quantity double precision NOT NULL,
    requester text NOT NULL,
    remark text,
    source_type text NOT NULL,
    source_gap_check_id text,
    source_listing_line_id text,
    purchase_order_id text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.purchase_requests FORCE ROW LEVEL SECURITY;


--
-- Name: purchase_returns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.purchase_returns (
    id text NOT NULL,
    tenant_id text NOT NULL,
    purchase_order_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    lines jsonb NOT NULL,
    returned_by text NOT NULL,
    remark text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.purchase_returns FORCE ROW LEVEL SECURITY;


--
-- Name: release_facts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.release_facts (
    id text NOT NULL,
    tenant_id text NOT NULL,
    inspection_id text NOT NULL,
    phase text NOT NULL,
    kind text NOT NULL,
    item_id text,
    drawing_no text,
    quantity double precision NOT NULL,
    source_type text,
    source_ref_id text,
    released_at timestamp(6) with time zone NOT NULL,
    recorded_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.release_facts FORCE ROW LEVEL SECURITY;


--
-- Name: report_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_audits (
    id text NOT NULL,
    tenant_id text NOT NULL,
    report_id text NOT NULL,
    action text NOT NULL,
    actor text NOT NULL,
    reason text,
    changes jsonb,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.report_audits FORCE ROW LEVEL SECURITY;


--
-- Name: reporting_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporting_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.reporting_events FORCE ROW LEVEL SECURITY;


--
-- Name: reporting_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.reporting_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reporting_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.reporting_events_seq_seq OWNED BY public.reporting_events.seq;


--
-- Name: reporting_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.reporting_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.reporting_operations FORCE ROW LEVEL SECURITY;


--
-- Name: resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.resources (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    type text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.resources FORCE ROW LEVEL SECURITY;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    tenant_id text NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL
);

ALTER TABLE ONLY public.roles FORCE ROW LEVEL SECURITY;


--
-- Name: routings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.routings (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text,
    steps jsonb NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.routings FORCE ROW LEVEL SECURITY;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    tenant_id text NOT NULL,
    user_id text NOT NULL,
    token_digest text NOT NULL,
    created_at timestamp(6) with time zone NOT NULL,
    expires_at timestamp(6) with time zone NOT NULL,
    refresh_expires_at timestamp(6) with time zone NOT NULL,
    revoked_at timestamp(6) with time zone
);

ALTER TABLE ONLY public.sessions FORCE ROW LEVEL SECURITY;


--
-- Name: shipping_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shipping_orders (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    lines jsonb NOT NULL,
    carrier text,
    tracking_no text,
    executed_by text NOT NULL,
    confirmed_by text,
    confirmed_at timestamp(6) with time zone,
    remark text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.shipping_orders FORCE ROW LEVEL SECURITY;


--
-- Name: standard_times; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.standard_times (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    scope text NOT NULL,
    target_code text NOT NULL,
    standard_seconds integer NOT NULL,
    preparation_seconds integer NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.standard_times FORCE ROW LEVEL SECURITY;


--
-- Name: stock_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_accounts (
    id text NOT NULL,
    tenant_id text NOT NULL,
    item_id text NOT NULL,
    warehouse_id text NOT NULL,
    qty_on_hand double precision DEFAULT 0 NOT NULL,
    qty_reserved double precision DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.stock_accounts FORCE ROW LEVEL SECURITY;


--
-- Name: stock_location_balances; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_location_balances (
    id text NOT NULL,
    tenant_id text NOT NULL,
    warehouse_id text NOT NULL,
    location_id text NOT NULL,
    item_id text NOT NULL,
    qty double precision DEFAULT 0 NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.stock_location_balances FORCE ROW LEVEL SECURITY;


--
-- Name: stock_movements; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_movements (
    id text NOT NULL,
    tenant_id text NOT NULL,
    seq bigint NOT NULL,
    kind text NOT NULL,
    item_id text NOT NULL,
    warehouse_id text NOT NULL,
    location_id text,
    quantity double precision NOT NULL,
    source_ref_type text,
    source_ref_id text,
    source_key text,
    transfer_id text,
    work_order_id text,
    remark text,
    occurred_at timestamp(6) with time zone NOT NULL,
    recorded_by text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.stock_movements FORCE ROW LEVEL SECURITY;


--
-- Name: stock_movements_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.stock_movements_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: stock_movements_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.stock_movements_seq_seq OWNED BY public.stock_movements.seq;


--
-- Name: stock_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stock_reservations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    reservation_key text NOT NULL,
    item_id text NOT NULL,
    warehouse_id text NOT NULL,
    quantity double precision NOT NULL,
    remaining double precision NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    ref_type text NOT NULL,
    ref_id text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.stock_reservations FORCE ROW LEVEL SECURITY;


--
-- Name: stocktakes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stocktakes (
    id text NOT NULL,
    tenant_id text NOT NULL,
    warehouse_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    lines jsonb NOT NULL,
    opened_by text NOT NULL,
    approved_by text,
    remark text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.stocktakes FORCE ROW LEVEL SECURITY;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.suppliers FORCE ROW LEVEL SECURITY;


--
-- Name: todos; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.todos (
    id text NOT NULL,
    tenant_id text NOT NULL,
    assignee_id text NOT NULL,
    title text NOT NULL,
    source text NOT NULL,
    ref_type text,
    ref_id text,
    status text DEFAULT 'open'::text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    due_at timestamp(6) with time zone
);

ALTER TABLE ONLY public.todos FORCE ROW LEVEL SECURITY;


--
-- Name: units; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.units (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    symbol text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.units FORCE ROW LEVEL SECURITY;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    tenant_id text NOT NULL,
    username text NOT NULL,
    display_name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    password_hash text
);

ALTER TABLE ONLY public.users FORCE ROW LEVEL SECURITY;


--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouse_locations (
    id text NOT NULL,
    tenant_id text NOT NULL,
    warehouse_id text NOT NULL,
    code text NOT NULL,
    name text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.warehouse_locations FORCE ROW LEVEL SECURITY;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.warehouses (
    id text NOT NULL,
    tenant_id text NOT NULL,
    code text NOT NULL,
    name text NOT NULL,
    default_location_id text NOT NULL,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.warehouses FORCE ROW LEVEL SECURITY;


--
-- Name: work_order_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_order_attachments (
    id text NOT NULL,
    tenant_id text NOT NULL,
    work_order_id text NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    ref text NOT NULL,
    attached_by text NOT NULL,
    attached_at timestamp(6) with time zone NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes text,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone
);

ALTER TABLE ONLY public.work_order_attachments FORCE ROW LEVEL SECURITY;


--
-- Name: work_order_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_order_records (
    id uuid NOT NULL,
    tenant_id text NOT NULL,
    work_order_id uuid NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    audit_status text NOT NULL,
    provenance jsonb,
    supersedes uuid,
    business_time timestamp(6) with time zone,
    available_time timestamp(6) with time zone,
    CONSTRAINT work_order_records_object_version_check CHECK ((object_version >= 1))
);

ALTER TABLE ONLY public.work_order_records FORCE ROW LEVEL SECURITY;


--
-- Name: work_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_orders (
    id text NOT NULL,
    tenant_id text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    customer_ref text,
    project_name text NOT NULL,
    sales_rep text,
    manager text,
    planned_delivery_at timestamp(6) with time zone,
    packaging_arrival_at timestamp(6) with time zone,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.work_orders FORCE ROW LEVEL SECURITY;


--
-- Name: work_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.work_reports (
    id text NOT NULL,
    tenant_id text NOT NULL,
    dispatch_id text NOT NULL,
    kind text NOT NULL,
    flow_config_id text NOT NULL,
    state text NOT NULL,
    object_version integer DEFAULT 1 NOT NULL,
    done_qty double precision NOT NULL,
    labor_minutes integer NOT NULL,
    reporter text NOT NULL,
    work_order_id text,
    drawing_no text,
    operation_code text,
    supersedes text,
    business_time timestamp(6) with time zone NOT NULL,
    verified_by text,
    verified_at timestamp(6) with time zone,
    revoked_by text,
    revoked_at timestamp(6) with time zone,
    revoke_reason text,
    remark text,
    created_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp(6) with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE ONLY public.work_reports FORCE ROW LEVEL SECURITY;


--
-- Name: workorder_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workorder_events (
    seq bigint NOT NULL,
    event_id text NOT NULL,
    tenant_id text NOT NULL,
    event_type character varying(128) NOT NULL,
    aggregate_id text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_revision integer NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL,
    payload jsonb NOT NULL
);

ALTER TABLE ONLY public.workorder_events FORCE ROW LEVEL SECURITY;


--
-- Name: workorder_events_seq_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.workorder_events_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: workorder_events_seq_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.workorder_events_seq_seq OWNED BY public.workorder_events.seq;


--
-- Name: workorder_operations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workorder_operations (
    operation_key text NOT NULL,
    tenant_id text NOT NULL,
    operation_id text NOT NULL,
    command text NOT NULL,
    aggregate_type text NOT NULL,
    aggregate_id text NOT NULL,
    occurred_at timestamp(6) with time zone NOT NULL
);

ALTER TABLE ONLY public.workorder_operations FORCE ROW LEVEL SECURITY;


--
-- Name: approval_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_events ALTER COLUMN seq SET DEFAULT nextval('public.approval_events_seq_seq'::regclass);


--
-- Name: cost_entries seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries ALTER COLUMN seq SET DEFAULT nextval('public.cost_entries_seq_seq'::regclass);


--
-- Name: dispatch_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_events ALTER COLUMN seq SET DEFAULT nextval('public.dispatch_events_seq_seq'::regclass);


--
-- Name: drawing_view_trails seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drawing_view_trails ALTER COLUMN seq SET DEFAULT nextval('public.drawing_view_trails_seq_seq'::regclass);


--
-- Name: earnings_records seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earnings_records ALTER COLUMN seq SET DEFAULT nextval('public.earnings_records_seq_seq'::regclass);


--
-- Name: fault_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fault_events ALTER COLUMN seq SET DEFAULT nextval('public.fault_events_seq_seq'::regclass);


--
-- Name: gap_checks seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_checks ALTER COLUMN seq SET DEFAULT nextval('public.gap_checks_seq_seq'::regclass);


--
-- Name: inspection_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_events ALTER COLUMN seq SET DEFAULT nextval('public.inspection_events_seq_seq'::regclass);


--
-- Name: inventory_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_events ALTER COLUMN seq SET DEFAULT nextval('public.inventory_events_seq_seq'::regclass);


--
-- Name: kit_checks seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kit_checks ALTER COLUMN seq SET DEFAULT nextval('public.kit_checks_seq_seq'::regclass);


--
-- Name: labor_entries seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_entries ALTER COLUMN seq SET DEFAULT nextval('public.labor_entries_seq_seq'::regclass);


--
-- Name: listing_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_events ALTER COLUMN seq SET DEFAULT nextval('public.listing_events_seq_seq'::regclass);


--
-- Name: maintenance_activities seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_activities ALTER COLUMN seq SET DEFAULT nextval('public.maintenance_activities_seq_seq'::regclass);


--
-- Name: reporting_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_events ALTER COLUMN seq SET DEFAULT nextval('public.reporting_events_seq_seq'::regclass);


--
-- Name: stock_movements seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements ALTER COLUMN seq SET DEFAULT nextval('public.stock_movements_seq_seq'::regclass);


--
-- Name: workorder_events seq; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workorder_events ALTER COLUMN seq SET DEFAULT nextval('public.workorder_events_seq_seq'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
9c45911f-e844-4006-8821-78856b226b6f	f848f8593a364fe5bf8bc396713a66c0a790ecb166f2dfc084665b7d025cd184	2026-10-25 14:52:24.64718+00	20261026060000_payroll_module	\N	\N	2026-10-25 14:52:24.599328+00	1
bb7bf3f2-90bc-4cb6-ac22-03113bd5dd64	19a17df3455f7f6203ea965c33ce31473f589f49b9f906230695d2cb148e09a7	2026-10-25 14:52:23.703491+00	20261024135930_init	\N	\N	2026-10-25 14:52:23.64807+00	1
d09169d4-d09e-4ea4-93bc-a15757ace988	51865b0eac6f6d969b04cb0bd626d5adf4bba9a68f385246e9b6de9eafb2a856	2026-10-25 14:52:24.342649+00	20261025230000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.327356+00	1
7289c5ae-d4ab-4886-bc0f-4c4eed6a0b41	85634bb89d8978d6264e2ace800f8e862b8ebdc5df81e9d511dd52936e6fa0e8	2026-10-25 14:52:23.734977+00	20261024163136_org_users_roles_policies	\N	\N	2026-10-25 14:52:23.70648+00	1
b631816c-8b19-4fe4-a511-e2be188f3d65	734601e998d86bb2d3d9396b7a0333a128932a250fa6cd5a3e3e23b854e9bfe9	2026-10-25 14:52:23.765519+00	20261025120000_masterdata_items_resources_todos	\N	\N	2026-10-25 14:52:23.737739+00	1
3519c347-9d45-46a2-bb85-1dd2c3af33f7	f1a09e1cc0f7df488e799e9e2c386ebc79eed854cc4c2f2ce6de5a5aa70953a8	2026-10-25 14:52:23.804938+00	20261025140000_approval_cases_records_events	\N	\N	2026-10-25 14:52:23.768211+00	1
65ee7a8d-7c6a-4d1e-8e2f-77f535247cb7	1635d0dc4ef51476966ca80782bb7037df8054711ba42d13e2b8b24276d31ab7	2026-10-25 14:52:24.393456+00	20261026010000_reporting_module	\N	\N	2026-10-25 14:52:24.344587+00	1
ede11924-be2f-4bec-8d15-7fec57e7e03e	124d0d67ea2a0639eb97be84b0b9071ff24e6547c1d3d102275c265a3cd01519	2026-10-25 14:52:23.822938+00	20261025150000_auth_password_hash_sessions	\N	\N	2026-10-25 14:52:23.807176+00	1
ccc45fd9-b0cf-40a3-af31-3af9c0cad95d	55decbd810703eff81676e5b76eca6304b4f4ce681a4d459f9ef478c9048c034	2026-10-25 14:52:23.886713+00	20261025160000_workorder_module	\N	\N	2026-10-25 14:52:23.824997+00	1
e46663fe-d28a-4933-a9c6-9f547caf50da	323f7d1fd1a62267022cb6c5857455879175b76856f340b80563aaab645795a3	2026-10-25 14:52:24.898361+00	20261026121000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.884413+00	1
76fab3fe-b4a3-49ab-a721-2167a339c415	b4b56b5c48c9265e796bce14ed02334ce8f797572dfa320425bc24623926f043	2026-10-25 14:52:23.965988+00	20261025180000_baseline_p1_masters_validation	\N	\N	2026-10-25 14:52:23.889356+00	1
5d77bec7-b1ad-4086-b57d-13aebd2da386	d8d9872182e6046b814595abf46e8efd2f30cfa8b2dd94f0655cbd9591252505	2026-10-25 14:52:24.413448+00	20261026010400_reporting_rls_replay	\N	\N	2026-10-25 14:52:24.396104+00	1
b9e25ac5-6298-4b14-8fb0-2df628f01db1	4adde292f75b5535f46f2724a0e9d7112794bd0ced782b22edca069cfff6485f	2026-10-25 14:52:24.037397+00	20261025190000_inspection_module	\N	\N	2026-10-25 14:52:23.970652+00	1
f6fb0739-e3fb-4062-a311-b027b403bc66	f703e55f912c4722c65003fca2a1774b6ae07d3432443c1b084d4f3d00b7c22b	2026-10-25 14:52:24.057012+00	20261025193000_rls_tenant_isolation	\N	\N	2026-10-25 14:52:24.040245+00	1
6d66266a-1402-43f7-a38c-208d25d4a83a	ba237eb77e173feb2b40fee52793cc5c1a6c5f427ba49a428ff97354740bef46	2026-10-25 14:52:24.665969+00	20261026061000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.649858+00	1
cc278412-e3f1-428b-967d-94639b3c336f	adf4c98a04c05821fa0b0a670b0da6edc26645ecd8b7cc4760d22df360892b89	2026-10-25 14:52:24.141767+00	20261025200000_listing_module	\N	\N	2026-10-25 14:52:24.059664+00	1
83ade9a3-b6e0-4258-bf16-fa768cd889f4	0a836abf3ed9f1d2420086b04f3d3c7b7b201462358de76b0cdbc2e7d15e46fa	2026-10-25 14:52:24.451584+00	20261026020000_hours_module	\N	\N	2026-10-25 14:52:24.415446+00	1
e2af8bee-066d-4388-a3e0-3dccdd1d4e54	1943f1ccad4c8649faa36ce99ecbf9a2a2e392225e774329064720b69ad2c82f	2026-10-25 14:52:24.156623+00	20261025210000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.14408+00	1
feed534e-08c1-4553-946a-9b8a53d78db1	33933e50686858fb0e6bf858e78ba3835767adca3d687d28cf1009533825a362	2026-10-25 14:52:24.209845+00	20261025220000_dispatch_module	\N	\N	2026-10-25 14:52:24.15903+00	1
7aed1241-7fe1-4240-80dc-0a76cbee80b9	40fa95c03a18aa2f46dd511125370c100c530beb99b95eeeedfcdcb43f542349	2026-10-25 14:52:24.325367+00	20261025220000_inventory_module	\N	\N	2026-10-25 14:52:24.2121+00	1
1c108868-7af3-4c33-90f0-6e0dccdd93a1	f488dcebb007f9a18765cad0fa12c6e49e862299996e85b1954e0c49c1deb769	2026-10-25 14:52:24.498043+00	20261026030000_costing_module	\N	\N	2026-10-25 14:52:24.453484+00	1
ec9ccaa2-119b-4d2b-af59-b012ccda8c23	6235ee7f192ec7abb55ee056c17adb82306c2eb0690e9f339bd5e2b5d948ffa2	2026-10-25 14:52:24.816753+00	20261026100000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.801678+00	1
5c0e40d1-02c9-46af-aaa0-008242c736f6	883207cc78cd5888ae8aed39ebee9517500da613cea14274e3ad2c6f4af58f06	2026-10-25 14:52:24.556225+00	20261026040000_baseline_p2_p3	\N	\N	2026-10-25 14:52:24.499956+00	1
3b2b5744-a635-4184-b5c1-2b727e5fd68d	28062868c8c8343b60ae4dae7d2971557da83e7a7dc74aa43be79d32747d397b	2026-10-25 14:52:24.714671+00	20261026070000_maintenance_module	\N	\N	2026-10-25 14:52:24.668215+00	1
7a244821-e599-431f-908e-032398f5edae	e75620013b694e9477a7da17e7d3e1ca8b24905a89c2450912a607f68834c053	2026-10-25 14:52:24.576197+00	20261026041000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.558816+00	1
dcc6b7bf-eb5e-46c8-9c82-7ae73b1ccfcf	588d8a8ba129c395d0222f115a0a0def10cf1496bfb8472a6ce7f9c5e7900412	2026-10-25 14:52:24.596905+00	20261026050000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.57849+00	1
ce749154-e62c-496a-b996-6cb27eb17f20	fdcb7ebc5868b68ac8d851f8273f88fee97b9298f251661259a2c46836f09682	2026-10-25 14:52:24.75571+00	20261026080000_drawing_module	\N	\N	2026-10-25 14:52:24.716802+00	1
548535ec-9da9-4315-85f9-404a3ff7ca53	935a2d7fb3d4031d83af31834722b8515aefb2a9346cac03717f70b6f06e5fd4	2026-10-25 14:52:24.83374+00	20261026110000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.819262+00	1
5eca5568-d5c4-4a9b-a54d-2849cbe97d0c	3aff048cc7dca4122dd89e49d643ef99a01679ead8873109d357065d57781039	2026-10-25 14:52:24.780512+00	20261026090000_metric_pack_module	\N	\N	2026-10-25 14:52:24.757982+00	1
7dcfd5de-c9b5-4139-8981-27a59d90e4d5	05da4f7756d457fc79d02917fa48cc611ba2caed4e35f01c15a2fc2eef7ea7af	2026-10-25 14:52:24.799129+00	20261026091000_rls_tenant_isolation_replay	\N	\N	2026-10-25 14:52:24.78313+00	1
68f8051c-a6e3-4aba-9c49-a884a2083a01	d2995be8920acaf76fc0a1e8ef3f363026bb4ebbd9258d3f43c3ef2f30c51802	2026-10-25 14:52:24.882417+00	20261026120000_backfill_module	\N	\N	2026-10-25 14:52:24.83577+00	1
\.


--
-- Data for Name: approval_cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_cases (id, tenant_id, flow_config_id, state, object_version, subject_type, subject_id, submitter_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: approval_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
\.


--
-- Data for Name: approval_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.approval_records (id, tenant_id, aggregate_id, aggregate_type, reviewer_id, decision, reason, evidence, object_version, decided_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, user_id, method, path, summary, occurred_at) FROM stdin;
\.


--
-- Data for Name: baseline_command_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.baseline_command_operations (id, tenant_id, operation_id, command_kind, claimed_at) FROM stdin;
01a17391-0c1c-72f0-b823-2f10cc7b3ba8	default	m2rec-baseline-fault-report	baseline.fault.report.v1	2026-10-25 14:57:28.092+00
01a17392-60d9-7214-a654-bd74dd74b3c4	default	m2rec-listing-import-part#material	baseline.material.validate.v1	2026-10-25 14:58:55.321+00
\.


--
-- Data for Name: cost_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_entries (id, tenant_id, seq, work_order_id, category, amount_minor, quantity, trade, source_type, source_ref_id, source_key, delta_of, work_date, remark, occurred_at, recorded_by, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
\.


--
-- Data for Name: cost_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cost_snapshots (id, tenant_id, work_order_id, model_code, model_version, totals, rebuilt_by, rebuilt_at, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: costing_models; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.costing_models (id, tenant_id, code, name, definition, status, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
01a17393-878d-7304-8fae-97e7c03eb239	default	m2reconcile	对账口径v1	{"allocation": {"method": "none"}, "hourlyRates": {"misc": 4000, "assembly": 5000, "aftercare": 5500, "machining": 6000, "electrical": 6500}, "categoryMapping": {"labor-entry": "labor", "outsourcing-line": "outsourcing", "inventory-movement": "material"}}	active	1	\N	published	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "costing.model.publish.v1", "operationId": "m2rec-costing-model-publish"}	2026-10-25 15:00:10.751+00	\N	2026-10-25 15:00:10.766+00
\.


--
-- Data for Name: costing_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.costing_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
01a17393-878a-718d-9452-ce9db55d2d84	default	m2rec-costing-model-publish	costing.model.publish.v1
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, tenant_id, code, name, contact, active, created_at) FROM stdin;
\.


--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (id, tenant_id, code, name, parent_id, active, created_at) FROM stdin;
\.


--
-- Data for Name: dispatch_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispatch_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-4d82cdea-ce13-497f-b9c1-12dec1400098	default	smes.dispatch-order.v1.assigned	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	dispatch-order	2	2026-10-25 14:55:45.883+00	{"to": "assigned", "from": "draft", "actor": "user-seed-admin", "event": "ASSIGN", "flowId": "dispatch-order", "reason": "派工到人", "objectVersion": 2}
2	evt-9bf92a21-f848-4501-b248-b9d9287c8457	default	smes.dispatch-order.v1.assigned	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	dispatch-order	2	2026-10-25 14:55:45.922+00	{"to": "assigned", "from": "draft", "actor": "user-seed-admin", "event": "ASSIGN", "flowId": "dispatch-order", "reason": "派工到人", "objectVersion": 2}
3	evt-f1be6568-769a-46cc-a126-0d9f717c8c85	default	smes.dispatch-order.v1.assigned	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	dispatch-order	2	2026-10-25 14:55:45.948+00	{"to": "assigned", "from": "draft", "actor": "user-seed-admin", "event": "ASSIGN", "flowId": "dispatch-order", "reason": "派工到人", "objectVersion": 2}
4	evt-0334ba4f-5e76-4417-8ffb-4f4e712bec5e	default	smes.dispatch-order.v1.assigned	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	dispatch-order	2	2026-10-25 14:55:45.974+00	{"to": "assigned", "from": "draft", "actor": "user-seed-admin", "event": "ASSIGN", "flowId": "dispatch-order", "reason": "派工到人", "objectVersion": 2}
\.


--
-- Data for Name: dispatch_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispatch_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2prep-dispatch-3	default	m2prep-dispatch-3	dispatch.create.v1	dispatch-order	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	2026-10-25 14:55:45.853+00
default|m2prep-dispatch-4	default	m2prep-dispatch-4	dispatch.assign.v1	dispatch-order	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	2026-10-25 14:55:45.883+00
default|m2prep-dispatch-5	default	m2prep-dispatch-5	dispatch.create.v1	dispatch-order	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	2026-10-25 14:55:45.91+00
default|m2prep-dispatch-6	default	m2prep-dispatch-6	dispatch.assign.v1	dispatch-order	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	2026-10-25 14:55:45.922+00
default|m2prep-dispatch-7	default	m2prep-dispatch-7	dispatch.create.v1	dispatch-order	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	2026-10-25 14:55:45.937+00
default|m2prep-dispatch-8	default	m2prep-dispatch-8	dispatch.assign.v1	dispatch-order	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	2026-10-25 14:55:45.948+00
default|m2prep-dispatch-9	default	m2prep-dispatch-9	dispatch.create.v1	dispatch-order	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	2026-10-25 14:55:45.963+00
default|m2prep-dispatch-10	default	m2prep-dispatch-10	dispatch.assign.v1	dispatch-order	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	2026-10-25 14:55:45.974+00
default|m2rec-dispatch-create-part	default	m2rec-dispatch-create-part	dispatch.create.v1	dispatch-order	dsp-01a17392-6277-7a6e-bb57-39c6bbb6575d	2026-10-25 14:58:55.735+00
default|m2rec-dispatch-create-outsourcing	default	m2rec-dispatch-create-outsourcing	dispatch.create.v1	dispatch-order	dsp-01a17392-6340-7a92-9120-9e22288e778e	2026-10-25 14:58:55.936+00
\.


--
-- Data for Name: dispatch_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispatch_orders (id, tenant_id, work_order_id, kind, flow_config_id, state, object_version, title, drawing_no, operation_code, material, size_spec, quantity, done_qty, assignee, due_at, remark, created_at, updated_at) FROM stdin;
dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	dispatch-order	assigned	2	零件派工：DWG-M2PREP-1 × OP-10	DWG-M2PREP-1	OP-10	\N	\N	10	0	user-seed-admin	\N	\N	2026-10-25 14:55:45.866+00	2026-10-25 14:55:45.888+00
dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	dispatch-order	assigned	2	零件派工：DWG-M2PREP-2 × OP-10	DWG-M2PREP-2	OP-10	\N	\N	10	0	user-seed-admin	\N	\N	2026-10-25 14:55:45.913+00	2026-10-25 14:55:45.926+00
dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	dispatch-order	assigned	2	零件派工：DWG-M2PREP-3 × OP-10	DWG-M2PREP-3	OP-10	\N	\N	10	0	user-seed-admin	\N	\N	2026-10-25 14:55:45.939+00	2026-10-25 14:55:45.952+00
dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	dispatch-order	assigned	2	零件派工：DWG-M2PREP-4 × OP-10	DWG-M2PREP-4	OP-10	\N	\N	10	0	user-seed-admin	\N	\N	2026-10-25 14:55:45.965+00	2026-10-25 14:55:45.977+00
dsp-01a17392-6277-7a6e-bb57-39c6bbb6575d	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	dispatch-order	draft	1	零件派工：DWG-M2REC-01 × OP-10	DWG-M2REC-01	OP-10	\N	\N	10	0	\N	\N	\N	2026-10-25 14:58:55.739+00	2026-10-25 14:58:55.739+00
dsp-01a17392-6340-7a92-9120-9e22288e778e	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	outsourcing	dispatch-order	draft	1	外协派工：对账外协一厂	\N	\N	\N	\N	5	0	\N	\N	\N	2026-10-25 14:58:55.94+00	2026-10-25 14:58:55.94+00
\.


--
-- Data for Name: drawing_change_notices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drawing_change_notices (id, tenant_id, drawing_id, from_version, to_version, change_note, published_at, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: drawing_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drawing_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
\.


--
-- Data for Name: drawing_revisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drawing_revisions (id, tenant_id, drawing_id, version, file_ref, change_note, classification, changed_by, changed_at, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: drawing_view_trails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.drawing_view_trails (id, tenant_id, seq, drawing_id, version, viewed_by, viewed_at, classification, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: earnings_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.earnings_records (id, tenant_id, seq, person_id, period_key, rule_id, rule_version, basis, labor_kind, quantity, rate_minor, coefficient, amount_minor, pay_run_id, source_refs, source_key, occurred_at, recorded_by, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
\.


--
-- Data for Name: equipment_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.equipment_records (id, tenant_id, code, name, type, location, status, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: event_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_records (event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, business_time, available_time, provenance, payload) FROM stdin;
evt-01a1738f-7c97-7ed1-b649-b8c3bb23be68	default	smes.workorder.v1.created	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	work-order	1	2026-10-25 14:55:45.815+00	\N	\N	{"actor": "user-seed-admin", "command": "workorder.create.v1", "operationId": "m2prep-workorder-1"}	{"actor": "user-seed-admin", "manager": null, "salesRep": null, "customerRef": null, "projectName": "M2对账-准备链A", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "listingKinds": ["part", "standard", "electrical", "equipment"], "plannedDeliveryAt": null, "packagingArrivalAt": null}
evt-01a1738f-7ccc-730a-a3f8-5ade24550ec4	default	smes.dispatch.v1.dispatch-created	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	dispatch-order	1	2026-10-25 14:55:45.868+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2prep-dispatch-3"}	{"kind": "part", "actor": "user-seed-admin", "dueAt": null, "title": "零件派工：DWG-M2PREP-1 × OP-10", "kitCheck": null, "material": null, "quantity": 10, "sizeSpec": null, "drawingNo": "DWG-M2PREP-1", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": "OP-10", "outsourcingLines": []}
evt-01a1738f-7ce3-7196-8a3c-e47e574892b8	default	smes.dispatch.v1.dispatch-assigned	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	dispatch-order	2	2026-10-25 14:55:45.891+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.assign.v1", "operationId": "m2prep-dispatch-4"}	{"actor": "user-seed-admin", "remark": null, "assignee": "user-seed-admin", "objectVersion": 2}
evt-01a1738f-7cfa-7178-99c8-fb97fa0665f5	default	smes.dispatch.v1.dispatch-created	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	dispatch-order	1	2026-10-25 14:55:45.914+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2prep-dispatch-5"}	{"kind": "part", "actor": "user-seed-admin", "dueAt": null, "title": "零件派工：DWG-M2PREP-2 × OP-10", "kitCheck": null, "material": null, "quantity": 10, "sizeSpec": null, "drawingNo": "DWG-M2PREP-2", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": "OP-10", "outsourcingLines": []}
evt-01a1738f-7d08-7355-beb7-d180e9dad6f0	default	smes.dispatch.v1.dispatch-assigned	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	dispatch-order	2	2026-10-25 14:55:45.928+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.assign.v1", "operationId": "m2prep-dispatch-6"}	{"actor": "user-seed-admin", "remark": null, "assignee": "user-seed-admin", "objectVersion": 2}
evt-01a1738f-7d14-70ea-ba31-4c3372e75eeb	default	smes.dispatch.v1.dispatch-created	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	dispatch-order	1	2026-10-25 14:55:45.94+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2prep-dispatch-7"}	{"kind": "part", "actor": "user-seed-admin", "dueAt": null, "title": "零件派工：DWG-M2PREP-3 × OP-10", "kitCheck": null, "material": null, "quantity": 10, "sizeSpec": null, "drawingNo": "DWG-M2PREP-3", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": "OP-10", "outsourcingLines": []}
evt-01a1738f-7d23-795a-a393-a621ab5c71d8	default	smes.dispatch.v1.dispatch-assigned	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	dispatch-order	2	2026-10-25 14:55:45.955+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.assign.v1", "operationId": "m2prep-dispatch-8"}	{"actor": "user-seed-admin", "remark": null, "assignee": "user-seed-admin", "objectVersion": 2}
evt-01a1738f-7d2e-7ac7-b1a6-de1ae6570b50	default	smes.dispatch.v1.dispatch-created	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	dispatch-order	1	2026-10-25 14:55:45.966+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2prep-dispatch-9"}	{"kind": "part", "actor": "user-seed-admin", "dueAt": null, "title": "零件派工：DWG-M2PREP-4 × OP-10", "kitCheck": null, "material": null, "quantity": 10, "sizeSpec": null, "drawingNo": "DWG-M2PREP-4", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": "OP-10", "outsourcingLines": []}
evt-01a1738f-7d3b-7c48-81cd-b7d5e049055e	default	smes.dispatch.v1.dispatch-assigned	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	dispatch-order	2	2026-10-25 14:55:45.979+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.assign.v1", "operationId": "m2prep-dispatch-10"}	{"actor": "user-seed-admin", "remark": null, "assignee": "user-seed-admin", "objectVersion": 2}
evt-01a1738f-7d57-79af-b895-fb40b26de49a	default	smes.reporting.v1.report-submitted	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	work-report	2	2026-10-25 14:55:46.007+00	\N	\N	{"actor": "user-seed-admin", "command": "report.submit.v1", "operationId": "m2prep-report-11"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-3", "dispatchId": "dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4", "supersedes": null, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:55:45.998Z", "laborMinutes": 90, "objectVersion": 2, "operationCode": "OP-10", "inspectionIntake": {"reason": "非工艺路线末道工序（不触发自制质检）", "created": false, "inspectionId": null}}
evt-01a1738f-7d68-7904-9a83-e471f6c35d77	default	smes.reporting.v1.report-submitted	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	2	2026-10-25 14:55:46.024+00	\N	\N	{"actor": "user-seed-admin", "command": "report.submit.v1", "operationId": "m2prep-report-12"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-4", "dispatchId": "dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26", "supersedes": null, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:55:46.017Z", "laborMinutes": 120, "objectVersion": 2, "operationCode": "OP-10", "inspectionIntake": {"reason": "非工艺路线末道工序（不触发自制质检）", "created": false, "inspectionId": null}}
evt-01a1738f-7d7b-7ad6-a632-c9d5bcac0aaf	default	smes.reporting.v1.report-verified	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	3	2026-10-25 14:55:46.043+00	\N	\N	{"actor": "user-seed-admin", "command": "report.verify.v1", "operationId": "m2prep-report-13"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-4", "dispatchId": "dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26", "supersedes": null, "verifiedAt": "2026-10-25T14:55:46.038Z", "verifiedBy": "user-seed-admin", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:55:46.017Z", "laborMinutes": 120, "objectVersion": 3, "operationCode": "OP-10"}
evt-01a17392-627d-73b0-bada-7cb31144ff03	default	smes.dispatch.v1.dispatch-created	dsp-01a17392-6277-7a6e-bb57-39c6bbb6575d	dispatch-order	1	2026-10-25 14:58:55.741+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2rec-dispatch-create-part"}	{"kind": "part", "actor": "user-seed-admin", "dueAt": null, "title": "零件派工：DWG-M2REC-01 × OP-10", "kitCheck": null, "material": null, "quantity": 10, "sizeSpec": null, "drawingNo": "DWG-M2REC-01", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": "OP-10", "outsourcingLines": []}
evt-14c73511-1046-4ffc-804e-1a93587d1379	default	smes.hours.v1.labor-entry-committed	01a1738f-7d90-76e2-9258-ff840d19693d	hours-labor-entry	1	2026-10-25 14:55:46.066+00	2026-10-25 00:00:00+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-28039740-4302-4c4f-848f-7bcbcf532d1e"}	{"hours": 2, "trade": "machining", "entryId": "01a1738f-7d90-76e2-9258-ff840d19693d", "reverses": null, "workDate": "2026-10-25", "workerId": "user-seed-admin", "direction": "commit", "drawingNo": "DWG-M2PREP-4", "outputQty": 10, "sourceKey": "report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:c1", "dispatchId": "dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26", "recordedBy": "user-seed-admin", "processCode": "OP-10", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "sourceReportId": "wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33"}
evt-01a1738f-7da7-774f-9207-8ac7e663f81c	default	smes.inspection.v1.created	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	inspection-order	1	2026-10-25 14:55:46.087+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.create.v1", "operationId": "m2prep-inspection-14"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "itemId": null, "quantity": 5, "drawingNo": null, "sourceType": null, "sourceRefId": null, "inspectionId": "insp-01a1738f-7d99-7623-8aeb-a12a230ca72c"}
evt-01a1738f-7db1-7c2d-9845-30f07297862a	default	smes.inspection.v1.created	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	1	2026-10-25 14:55:46.097+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.create.v1", "operationId": "m2prep-inspection-15"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "itemId": null, "quantity": 5, "drawingNo": null, "sourceType": null, "sourceRefId": null, "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357"}
evt-01a1738f-7dc4-7e17-8132-ac8c79a7702b	default	smes.inspection.v1.judged	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	2	2026-10-25 14:55:46.116+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.judge.v1", "operationId": "m2prep-inspection-16"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "phase": "judge", "remark": null, "outcome": "failed", "failedQty": 5, "passedQty": 0, "closeDueAt": "2026-10-28T14:55:46.110Z", "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357", "nonconformId": "nc-01a1738f-7dc1-7336-8763-2101cc1d73f4", "objectVersion": 2}
evt-01a1738f-7de6-7d9c-8d5e-c603f3011742	default	smes.inspection.v1.nonconform-disposed	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	nonconform	2	2026-10-25 14:55:46.15+00	\N	\N	{"actor": "user-seed-admin", "command": "nonconform.dispose.v1", "operationId": "m2prep-nonconform-17"}	{"actor": "user-seed-admin", "reason": "M2 准备链-返工处置", "remark": null, "disposal": "rework", "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357", "nonconformId": "nc-01a1738f-7dc1-7336-8763-2101cc1d73f4", "objectVersion": 2, "recheckRequired": true}
evt-01a1738f-7e02-7627-baa5-aacdfb7bb709	default	smes.inspection.v1.judged	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	3	2026-10-25 14:55:46.178+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.recheck.v1", "operationId": "m2prep-inspection-18"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "phase": "recheck", "remark": null, "outcome": "passed", "failedQty": 0, "passedQty": 5, "closeDueAt": null, "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357", "nonconformId": null, "objectVersion": 3}
evt-01a1738f-7e02-767f-bc87-ade4a230614f	default	smes.inspection.v1.released	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	3	2026-10-25 14:55:46.178+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.recheck.v1", "operationId": "m2prep-inspection-18"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "phase": "recheck", "itemId": null, "quantity": 5, "drawingNo": null, "sourceType": null, "sourceRefId": null, "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357", "objectVersion": 3}
evt-e254e775-7e39-4361-8fd8-5224a10313b8	default	smes.baseline.v1.fault-reported	fr-01a17391-0c20-7226-a261-ab3e5eec3ffc	baseline-fault-report	2	2026-10-25 14:57:28.107+00	\N	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "baseline.fault.report.v1", "operationId": "m2rec-baseline-fault-report"}	{"state": "assigned", "todoId": "01a17391-0c2f-706b-b194-a1857be1b23a", "assignee": "user-seed-admin", "reportedBy": "user-seed-admin", "description": "对账-主轴异响停机待检", "equipmentCode": "EQ-M2REC-01", "faultReportId": "fr-01a17391-0c20-7226-a261-ab3e5eec3ffc", "objectVersion": 2}
evt-01a17391-0dc5-7785-a936-92ba401fbe05	default	smes.workorder.v1.created	wo-01a17391-0dbd-7513-a7ee-500afc5ad012	work-order	1	2026-10-25 14:57:28.517+00	\N	\N	{"actor": "user-seed-admin", "command": "workorder.create.v1", "operationId": "m2rec-workorder-create"}	{"actor": "user-seed-admin", "manager": null, "salesRep": null, "customerRef": null, "projectName": "M2对账-工作令-01", "workOrderId": "wo-01a17391-0dbd-7513-a7ee-500afc5ad012", "listingKinds": ["part", "standard", "electrical", "equipment"], "plannedDeliveryAt": "2026-12-31T00:00:00.000Z", "packagingArrivalAt": "2026-12-20T00:00:00.000Z"}
evt-01a17391-0eb3-748a-b448-8fd4f5668537	default	smes.listing.v1.purchase-order-submitted	po-01a17391-0e92-7254-9ad9-0f5938f66b58	purchase-order	2	2026-10-25 14:57:28.755+00	\N	\N	{"actor": "user-seed-admin", "command": "purchase.order.submit.v1", "operationId": "m2rec-purchase-order-submit"}	{"actor": "user-seed-admin", "lines": [{"itemId": "item-m2rec-01", "lineNo": 1, "quantity": 20, "drawingNo": null, "receivedQty": 0, "unitPriceMinor": 12500}], "promisedAt": "2026-12-01", "requestIds": [], "supplierRef": "SUP-M2REC-01", "workOrderId": null, "supplierName": "对账供应商一厂", "objectVersion": 2}
evt-cc138b9a-44f7-4fca-ae45-8f4359ca0fc0	default	smes.baseline.v1.material-validated	01a17392-60db-759d-9b20-3d3334e31b16	baseline-material-validation	1	2026-10-25 14:58:55.326+00	2026-10-25 14:58:55.281+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "baseline.material.validate.v1", "operationId": "m2rec-listing-import-part#material"}	{"lines": [{"code": "C-XL-1", "name": "端盖", "spec": "规格X", "basis": "none", "lineNo": 1, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}, {"code": "C-XL-2", "name": "压盖", "spec": "规格Y", "basis": "none", "lineNo": 2, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}], "runId": "01a17392-60db-759d-9b20-3d3334e31b16", "summary": {"total": 2, "matched": 0, "suspected": 0, "unmatched": 2}}
evt-01a17392-60e6-7603-a66f-36d8c9a54344	default	smes.listing.v1.listing-imported	ls-01a17392-60c3-7ecc-8a24-8c7434b49661	listing-sheet	1	2026-10-25 14:58:55.334+00	\N	\N	{"actor": "user-seed-admin", "command": "listing.import.v1", "operationId": "m2rec-listing-import-part"}	{"kind": "part", "actor": "user-seed-admin", "source": "excel", "sheetId": "ls-01a17392-60c3-7ecc-8a24-8c7434b49661", "rowIssues": [], "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "sourceEventId": null, "importedLineCount": 2, "previousLineCount": 0}
evt-01a17392-60e6-7527-86a5-f464222e66f6	default	smes.listing.v1.listing-line-validated	ls-01a17392-60c3-7ecc-8a24-8c7434b49661	listing-sheet	1	2026-10-25 14:58:55.334+00	\N	\N	{"actor": "user-seed-admin", "command": "listing.import.v1", "operationId": "m2rec-listing-import-part"}	{"kind": "part", "actor": "user-seed-admin", "lines": [{"code": "C-XL-1", "name": "端盖", "spec": "规格X", "basis": "none", "lineId": "ll-01a17392-60e2-76a0-88fb-5bc926426c98", "lineNo": 1, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}, {"code": "C-XL-2", "name": "压盖", "spec": "规格Y", "basis": "none", "lineId": "ll-01a17392-60e2-7aa3-8293-0f573fd24394", "lineNo": 2, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}], "sheetId": "ls-01a17392-60c3-7ecc-8a24-8c7434b49661", "summary": {"total": 2, "matched": 0, "suspected": 0, "unmatched": 2}, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79"}
evt-01a17392-61b2-71cc-b6a2-cc74cb107c78	default	smes.listing.v1.gap-checked	gap-01a17392-61ac-76e0-a5a0-b1b63510af44	gap-check	1	2026-10-25 14:58:55.538+00	\N	\N	{"actor": "user-seed-admin", "command": "gap.check.v1", "operationId": "m2rec-listing-gap-check"}	{"actor": "user-seed-admin", "kinds": [{"kind": "part", "complete": true, "lineCount": 2, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "standard", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "electrical", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "equipment", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}], "complete": true, "gapLines": [], "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79"}
evt-01a17392-634a-768e-ad42-d69e733f697d	default	smes.dispatch.v1.dispatch-created	dsp-01a17392-6340-7a92-9120-9e22288e778e	dispatch-order	1	2026-10-25 14:58:55.947+00	\N	\N	{"actor": "user-seed-admin", "command": "dispatch.create.v1", "operationId": "m2rec-dispatch-create-outsourcing"}	{"kind": "outsourcing", "actor": "user-seed-admin", "dueAt": null, "title": "外协派工：对账外协一厂", "kitCheck": null, "material": null, "quantity": 5, "sizeSpec": null, "drawingNo": null, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "objectVersion": 1, "operationCode": null, "outsourcingLines": [{"lineId": "osl-01a17392-6344-7391-a2a9-818a0ecf6944", "lineNo": 1, "quantity": 5, "promisedAt": "2026-12-01T00:00:00.000Z", "priceSource": "manual", "processCode": "OP-M2REC-OS", "supplierRef": "SUP-M2REC-OS-01", "unitPriceMinor": 30000, "marginPermyriad": null}]}
evt-01a17392-64d9-7cbe-8cc3-acdbf47b9621	default	smes.workorder.v1.kit-check-refreshed	kc-01a17392-64cf-7503-84ea-39d1dfade432	kit-check	1	2026-10-25 14:58:56.345+00	\N	\N	{"actor": "user-seed-admin", "command": "workorder.kit.refresh.v1", "operationId": "m2rec-workorder-kit-refresh"}	{"actor": "user-seed-admin", "kinds": [{"kind": "part", "complete": true, "lineCount": 0, "gapLineCount": 0}, {"kind": "standard", "complete": true, "lineCount": 0, "gapLineCount": 0}, {"kind": "electrical", "complete": true, "lineCount": 0, "gapLineCount": 0}], "complete": true, "gapLines": [], "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79"}
evt-01a17393-363f-7c11-badd-d0bb00c837bc	default	smes.workorder.v1.transitioned	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	work-order	2	2026-10-25 14:59:49.951+00	\N	\N	{"actor": "user-seed-admin", "command": "workorder.transition.v1", "operationId": "m2rec-workorder-transition"}	{"to": "in_progress", "from": "not_started", "actor": "user-seed-admin", "event": "START", "remark": "流转至 进行中", "evidence": [], "objectVersion": 2}
evt-01a17393-4d36-72c6-96a4-704b4cffafc3	default	smes.reporting.v1.report-submitted	wr-01a17393-4d28-7851-ab48-11d3a17b4378	work-report	2	2026-10-25 14:59:55.83+00	\N	\N	{"actor": "user-seed-admin", "command": "report.submit.v1", "operationId": "m2rec-report-submit"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a17393-4d28-7851-ab48-11d3a17b4378", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-1", "dispatchId": "dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00", "supersedes": null, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:59:55.819Z", "laborMinutes": 90, "objectVersion": 2, "operationCode": "OP-10", "inspectionIntake": {"reason": "非工艺路线末道工序（不触发自制质检）", "created": false, "inspectionId": null}}
evt-01a17393-4d4d-7c31-8845-04ea7226b413	default	smes.reporting.v1.report-submitted	wr-01a17393-4d45-7fdc-8414-b96a906e1bd3	work-report	2	2026-10-25 14:59:55.853+00	\N	\N	{"actor": "user-seed-admin", "command": "report.submit-batch.v1", "operationId": "m2rec-report-submit-batch"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 4, "reportId": "wr-01a17393-4d45-7fdc-8414-b96a906e1bd3", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-2", "dispatchId": "dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369", "supersedes": null, "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:59:55.845Z", "laborMinutes": 120, "objectVersion": 2, "operationCode": "OP-10", "inspectionIntake": {"reason": "非工艺路线末道工序（不触发自制质检）", "created": false, "inspectionId": null}}
evt-01a17393-4d50-74a8-85c2-7c702b440703	default	smes.reporting.v1.batch-submitted	wr-01a17393-4d42-7207-bf39-7c63dfe6adfb	report-batch	1	2026-10-25 14:59:55.856+00	\N	\N	{"actor": "user-seed-admin", "command": "report.submit-batch.v1", "operationId": "m2rec-report-submit-batch"}	{"actor": "user-seed-admin", "count": 1, "reports": [{"kind": "part", "doneQty": 4, "reportId": "wr-01a17393-4d45-7fdc-8414-b96a906e1bd3", "reporter": "user-seed-admin", "dispatchId": "dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369", "laborMinutes": 120, "objectVersion": 2}]}
evt-01a17393-4ef6-76a4-978e-7199071086c0	default	smes.reporting.v1.report-verified	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	work-report	3	2026-10-25 14:59:56.278+00	\N	\N	{"actor": "user-seed-admin", "command": "report.verify.v1", "operationId": "m2rec-report-verify"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-3", "dispatchId": "dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4", "supersedes": null, "verifiedAt": "2026-10-25T14:59:56.273Z", "verifiedBy": "user-seed-admin", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:55:45.998Z", "laborMinutes": 90, "objectVersion": 3, "operationCode": "OP-10"}
evt-01a17393-4fd4-792d-9e6a-cc660eefbfaf	default	smes.reporting.v1.report-revoked	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	4	2026-10-25 14:59:56.5+00	\N	\N	{"actor": "user-seed-admin", "command": "report.revoke.v1", "operationId": "m2rec-report-revoke"}	{"kind": "part", "actor": "user-seed-admin", "doneQty": 10, "reportId": "wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33", "reporter": "user-seed-admin", "drawingNo": "DWG-M2PREP-4", "fromState": "verified", "dispatchId": "dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "businessTime": "2026-10-25T14:55:46.017Z", "laborMinutes": 120, "revokeReason": "对账-撤销冲销验证", "objectVersion": 4, "operationCode": "OP-10"}
evt-af6fa5de-a90e-415b-afbf-9f708b241659	default	smes.hours.v1.labor-entry-committed	01a17393-4f01-7029-8486-de5348cde400	hours-labor-entry	1	2026-10-25 14:59:56.291+00	2026-10-25 00:00:00+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-007307c3-44bf-4583-9395-31f5708aff01"}	{"hours": 1.5, "trade": "machining", "entryId": "01a17393-4f01-7029-8486-de5348cde400", "reverses": null, "workDate": "2026-10-25", "workerId": "user-seed-admin", "direction": "commit", "drawingNo": "DWG-M2PREP-3", "outputQty": 10, "sourceKey": "report:wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4:c1", "dispatchId": "dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4", "recordedBy": "user-seed-admin", "processCode": "OP-10", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "sourceReportId": "wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4"}
evt-91ddfda0-31f7-4f14-a89f-54cba74f4892	default	smes.hours.v1.labor-entry-reversed	01a17393-4fdf-7528-bc0c-6a7f1bfcb1f1	hours-labor-entry	1	2026-10-25 14:59:56.514+00	2026-10-25 00:00:00+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-e85d45bd-640d-48a1-bfc9-d46c2442b3f1"}	{"hours": 2, "trade": "machining", "entryId": "01a17393-4fdf-7528-bc0c-6a7f1bfcb1f1", "reverses": "01a1738f-7d90-76e2-9258-ff840d19693d", "workDate": "2026-10-25", "workerId": "user-seed-admin", "direction": "reverse", "drawingNo": "DWG-M2PREP-4", "outputQty": 10, "sourceKey": "report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:r1", "dispatchId": "dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26", "recordedBy": "user-seed-admin", "processCode": "OP-10", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "sourceReportId": "wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33"}
evt-5495a6ea-2079-408f-a69e-96c536578fe8	default	smes.hours.v1.labor-month-rebuilt	user-seed-admin|2026-10|machining	hours-labor-month	1	2026-10-25 15:00:10.547+00	2026-10-01 00:00:00+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.rebuild-month.v1", "operationId": "m2rec-hours-rebuild-month"}	{"month": "2026-10", "trade": "machining", "changed": true, "workerId": "user-seed-admin", "outputQty": 10, "rebuiltBy": "user-seed-admin", "entryCount": 1, "totalHours": 1.5, "objectVersion": 1}
evt-01a17393-50b1-75c5-9b40-6959776f963e	default	smes.inspection.v1.judged	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	inspection-order	2	2026-10-25 14:59:56.721+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.judge.v1", "operationId": "m2rec-inspection-judge"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "phase": "judge", "remark": null, "outcome": "passed", "failedQty": 0, "passedQty": 5, "closeDueAt": null, "inspectionId": "insp-01a1738f-7d99-7623-8aeb-a12a230ca72c", "nonconformId": null, "objectVersion": 2}
evt-01a17393-50b1-7027-8f30-1a876c63708d	default	smes.inspection.v1.released	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	inspection-order	2	2026-10-25 14:59:56.721+00	\N	\N	{"actor": "user-seed-admin", "command": "inspection.judge.v1", "operationId": "m2rec-inspection-judge"}	{"kind": "self_outsourced", "actor": "user-seed-admin", "phase": "judge", "itemId": null, "quantity": 5, "drawingNo": null, "sourceType": null, "sourceRefId": null, "inspectionId": "insp-01a1738f-7d99-7623-8aeb-a12a230ca72c", "objectVersion": 2}
evt-01a17393-5181-7ca6-b171-60e064a9191f	default	smes.inspection.v1.nonconform-closed	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	nonconform	3	2026-10-25 14:59:56.929+00	\N	\N	{"actor": "user-seed-admin", "command": "nonconform.close.v1", "operationId": "m2rec-inspection-nonconform-close"}	{"actor": "user-seed-admin", "remark": "对账-闭环", "disposal": "rework", "orderClosed": false, "inspectionId": "insp-01a1738f-7dad-71b1-afc6-2de80920b357", "nonconformId": "nc-01a1738f-7dc1-7336-8763-2101cc1d73f4", "objectVersion": 3}
evt-01a17393-84f8-7edb-8ff9-2ffbc51b1a97	default	smes.inventory.v1.stock-received	mv-01a17393-84ea-7e6f-94ee-8de554b77269	stock-movement	1	2026-10-25 15:00:10.104+00	\N	\N	{"actor": "user-seed-admin", "command": "stock.receive.v1", "operationId": "m2rec-inventory-stock-receive"}	{"actor": "user-seed-admin", "itemId": "item-m2rec-01", "source": "production", "quantity": 10, "duplicate": false, "qtyOnHand": 10, "locationId": "loc-01a1738f-7cae-7640-9114-c3f6cb52ea6e", "receiptKey": null, "qtyReserved": 0, "sourceRefId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "warehouseId": "wh-01a1738f-7cae-756e-8663-5b0981e502be", "workOrderId": "wo-01a1738f-7c86-7723-85a2-95c9da0f3b79", "movementKind": "production-in"}
evt-5c688e7d-15b6-42e5-a822-1d48198e3613	default	smes.costing.v1.costing-model-published	m2reconcile	costing-model	1	2026-10-25 15:00:10.769+00	2026-10-25 15:00:10.751+00	\N	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "costing.model.publish.v1", "operationId": "m2rec-costing-model-publish"}	{"code": "m2reconcile", "name": "对账口径v1", "status": "active", "definition": {"allocation": {"method": "none"}, "hourlyRates": {"misc": 4000, "assembly": 5000, "aftercare": 5500, "machining": 6000, "electrical": 6500}, "categoryMapping": {"labor-entry": "labor", "outsourcing-line": "outsourcing", "inventory-movement": "material"}}, "supersedes": null, "objectVersion": 1}
\.


--
-- Data for Name: fault_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fault_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-813b217a-ada1-4de1-9d4b-602486740953	default	smes.baseline-fault-report.v1.assigned	fr-01a17391-0c20-7226-a261-ab3e5eec3ffc	baseline-fault-report	2	2026-10-25 14:57:28.104+00	{"to": "assigned", "from": "open", "actor": "user-seed-admin", "event": "ASSIGN", "flowId": "baseline-fault-report", "reason": "对账-主轴异响停机待检", "objectVersion": 2}
\.


--
-- Data for Name: fault_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.fault_reports (id, tenant_id, flow_config_id, state, object_version, equipment_code, description, reported_by, assignee, assigned_at, resolution_remark, resolved_by, resolved_at, created_at, updated_at) FROM stdin;
fr-01a17391-0c20-7226-a261-ab3e5eec3ffc	default	baseline-fault-report	assigned	2	EQ-M2REC-01	对账-主轴异响停机待检	user-seed-admin	user-seed-admin	2026-10-25 14:57:28.107+00	\N	\N	\N	2026-10-25 14:57:28.097+00	2026-10-25 14:57:28.107+00
\.


--
-- Data for Name: gap_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.gap_checks (id, tenant_id, work_order_id, seq, kinds, gap_lines, complete, checked_by, checked_at, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
gap-01a17392-61ac-76e0-a5a0-b1b63510af44	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	1	[{"kind": "part", "complete": true, "lineCount": 2, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "standard", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "electrical", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}, {"kind": "equipment", "complete": true, "lineCount": 0, "gapLineCount": 0, "checkedLineCount": 0}]	[]	t	user-seed-admin	2026-10-25 14:58:55.535+00	1	recorded	{"actor": "user-seed-admin", "command": "gap.check.v1", "operationId": "m2rec-listing-gap-check"}	\N	\N	\N
\.


--
-- Data for Name: hours_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hours_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
01a1738f-7d81-76ed-a892-e849a1568b4f	default	wiring-hours-ingest-28039740-4302-4c4f-848f-7bcbcf532d1e	hours.ingest.v1
01a1738f-7d8d-7050-8c54-667f318a49e7	default	hours-ledger-report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:c1	hours.ingest.v1
01a17393-4efc-75c1-9f53-2de6d40493b7	default	wiring-hours-ingest-007307c3-44bf-4583-9395-31f5708aff01	hours.ingest.v1
01a17393-4eff-70be-96e3-c8d1e8d95f4d	default	hours-ledger-report:wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4:c1	hours.ingest.v1
01a17393-4fda-729c-af8b-1b69cfe2121d	default	wiring-hours-ingest-e85d45bd-640d-48a1-bfc9-d46c2442b3f1	hours.ingest.v1
01a17393-4fdd-75bf-ac33-2a475de0e486	default	hours-ledger-report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:r1	hours.ingest.v1
01a17393-86ab-7261-91f9-0fcb464c3a2c	default	m2rec-hours-rebuild-month	hours.rebuild-month.v1
\.


--
-- Data for Name: inspection_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-ecf7737d-4720-4814-bd1c-84e162c6e82a	default	smes.inspection-order.v1.failed	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	2	2026-10-25 14:55:46.106+00	{"to": "failed", "from": "pending", "actor": "user-seed-admin", "event": "FAIL", "flowId": "inspection-order", "reason": "判定不合格 0/5", "record": {"reason": "判定不合格 0/5", "decision": "reject", "evidence": [], "reviewer": "user-seed-admin", "decidedAt": "2026-10-25T14:55:46.106Z", "objectVersion": 1}, "objectVersion": 2}
2	evt-0fdb60ee-be61-4702-b0e0-d48c0ed449ca	default	smes.nonconform.v1.disposed	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	nonconform	2	2026-10-25 14:55:46.143+00	{"to": "disposed", "from": "open", "actor": "user-seed-admin", "event": "DISPOSE", "flowId": "nonconform", "reason": "M2 准备链-返工处置", "objectVersion": 2}
3	evt-a710f1f8-5014-45ec-837e-eb678ef20e55	default	smes.inspection-order.v1.recheck-passed	insp-01a1738f-7dad-71b1-afc6-2de80920b357	inspection-order	3	2026-10-25 14:55:46.168+00	{"to": "passed", "from": "failed", "actor": "user-seed-admin", "event": "RECHECK_PASS", "flowId": "inspection-order", "reason": "复检合格 5/0", "record": {"reason": "复检合格 5/0", "decision": "approve", "evidence": [], "reviewer": "user-seed-admin", "decidedAt": "2026-10-25T14:55:46.168Z", "objectVersion": 2}, "objectVersion": 3}
4	evt-52153b86-857b-41b0-a84c-51b0c36af59d	default	smes.inspection-order.v1.passed	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	inspection-order	2	2026-10-25 14:59:56.708+00	{"to": "passed", "from": "pending", "actor": "user-seed-admin", "event": "PASS", "flowId": "inspection-order", "reason": "判定合格 5/0", "record": {"reason": "判定合格 5/0", "decision": "approve", "evidence": [], "reviewer": "user-seed-admin", "decidedAt": "2026-10-25T14:59:56.708Z", "objectVersion": 1}, "objectVersion": 2}
5	evt-19d00760-b874-4521-8543-70a20857123e	default	smes.nonconform.v1.closed	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	nonconform	3	2026-10-25 14:59:56.919+00	{"to": "closed", "from": "disposed", "actor": "user-seed-admin", "event": "CLOSE", "flowId": "nonconform", "reason": "对账-闭环", "objectVersion": 3}
\.


--
-- Data for Name: inspection_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspection_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2prep-inspection-14	default	m2prep-inspection-14	inspection.create.v1	inspection-order	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	2026-10-25 14:55:46.074+00
default|m2prep-inspection-15	default	m2prep-inspection-15	inspection.create.v1	inspection-order	insp-01a1738f-7dad-71b1-afc6-2de80920b357	2026-10-25 14:55:46.094+00
default|m2prep-inspection-16	default	m2prep-inspection-16	inspection.judge.v1	inspection-order	insp-01a1738f-7dad-71b1-afc6-2de80920b357	2026-10-25 14:55:46.106+00
default|m2prep-nonconform-17	default	m2prep-nonconform-17	nonconform.dispose.v1	nonconform	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	2026-10-25 14:55:46.143+00
default|m2prep-inspection-18	default	m2prep-inspection-18	inspection.recheck.v1	inspection-order	insp-01a1738f-7dad-71b1-afc6-2de80920b357	2026-10-25 14:55:46.161+00
default|m2rec-inspection-judge	default	m2rec-inspection-judge	inspection.judge.v1	inspection-order	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	2026-10-25 14:59:56.708+00
default|m2rec-inspection-nonconform-close	default	m2rec-inspection-nonconform-close	nonconform.close.v1	nonconform	nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	2026-10-25 14:59:56.919+00
\.


--
-- Data for Name: inspections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inspections (id, tenant_id, flow_config_id, state, object_version, kind, source_type, source_ref_id, item_id, drawing_no, quantity, passed_qty, failed_qty, judge_remark, judged_by, judged_at, close_due_at, overdue_notified_at, created_at, updated_at) FROM stdin;
insp-01a1738f-7dad-71b1-afc6-2de80920b357	default	inspection-order	passed	3	self_outsourced	\N	\N	\N	\N	5	5	0	\N	user-seed-admin	2026-10-25 14:55:46.164+00	\N	\N	2026-10-25 14:55:46.096+00	2026-10-25 14:55:46.172+00
insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	default	inspection-order	passed	2	self_outsourced	\N	\N	\N	\N	5	5	0	\N	user-seed-admin	2026-10-25 14:59:56.718+00	\N	\N	2026-10-25 14:55:46.085+00	2026-10-25 14:59:56.718+00
\.


--
-- Data for Name: inventory_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-01a17393-85d7-7fe6-b928-9701c77475fa	default	smes.stocktake.v1.counting-started	st-01a17393-85d1-7928-b15f-84c8935ae378	stocktake	2	2026-10-25 15:00:10.327+00	{"to": "counting", "from": "draft", "actor": "user-seed-admin", "event": "START", "flowId": "stocktake", "reason": "盘点开单", "objectVersion": 2}
\.


--
-- Data for Name: inventory_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.inventory_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2prep-warehouse-2	default	m2prep-warehouse-2	warehouse.define.v1	warehouse	wh-01a1738f-7cae-756e-8663-5b0981e502be	2026-10-25 14:55:45.838+00
default|m2rec-inventory-warehouse-define	default	m2rec-inventory-warehouse-define	warehouse.define.v1	warehouse	wh-01a17391-0f86-7636-8240-cf22ff784321	2026-10-25 14:57:28.966+00
default|m2rec-inventory-stock-receive	default	m2rec-inventory-stock-receive	stock.receive.v1	stock-movement	receive	2026-10-25 15:00:10.081+00
default|m2rec-inventory-stocktake-open	default	m2rec-inventory-stocktake-open	stocktake.open.v1	stocktake	st-01a17393-85d1-7928-b15f-84c8935ae378	2026-10-25 15:00:10.321+00
\.


--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.items (id, tenant_id, code, name, spec, unit, category, active, created_at) FROM stdin;
\.


--
-- Data for Name: kit_checks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kit_checks (id, tenant_id, work_order_id, seq, kinds, gap_lines, complete, refreshed_by, refreshed_at, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
kc-01a17392-64cf-7503-84ea-39d1dfade432	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	1	[{"kind": "part", "complete": true, "lineCount": 0, "gapLineCount": 0}, {"kind": "standard", "complete": true, "lineCount": 0, "gapLineCount": 0}, {"kind": "electrical", "complete": true, "lineCount": 0, "gapLineCount": 0}]	[]	t	user-seed-admin	2026-10-25 14:58:56.342+00	1	recorded	{"actor": "user-seed-admin", "command": "workorder.kit.refresh.v1", "operationId": "m2rec-workorder-kit-refresh"}	\N	\N	\N
\.


--
-- Data for Name: labor_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_entries (id, tenant_id, seq, worker_id, work_date, trade, process_code, hours, output_qty, direction, source_report_id, reverses, work_order_id, drawing_no, dispatch_id, source_key, remark, occurred_at, recorded_by, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
01a1738f-7d90-76e2-9258-ff840d19693d	default	1	user-seed-admin	2026-10-25	machining	OP-10	2	10	commit	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	\N	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-4	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:c1	\N	2026-10-25 14:55:46.064+00	user-seed-admin	1	verified	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-28039740-4302-4c4f-848f-7bcbcf532d1e"}	\N	2026-10-25 00:00:00+00	\N
01a17393-4f01-7029-8486-de5348cde400	default	2	user-seed-admin	2026-10-25	machining	OP-10	1.5	10	commit	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	\N	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-3	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	report:wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4:c1	\N	2026-10-25 14:59:56.289+00	user-seed-admin	1	verified	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-007307c3-44bf-4583-9395-31f5708aff01"}	\N	2026-10-25 00:00:00+00	\N
01a17393-4fdf-7528-bc0c-6a7f1bfcb1f1	default	3	user-seed-admin	2026-10-25	machining	OP-10	2	10	reverse	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	01a1738f-7d90-76e2-9258-ff840d19693d	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-4	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	report:wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33:r1	对账-撤销冲销验证	2026-10-25 14:59:56.511+00	user-seed-admin	1	verified	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.ingest.v1", "operationId": "wiring-hours-ingest-e85d45bd-640d-48a1-bfc9-d46c2442b3f1"}	\N	2026-10-25 00:00:00+00	\N
\.


--
-- Data for Name: labor_ledger_months; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.labor_ledger_months (id, tenant_id, worker_id, month, trade, total_hours, output_qty, entry_count, first_work_date, last_work_date, rebuilt_by, rebuilt_at, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
01a17393-86b0-740e-9fa7-eb45fda7f1c2	default	user-seed-admin	2026-10	machining	1.5	10	1	2026-10-25	2026-10-25	user-seed-admin	2026-10-25 15:00:10.544+00	1	\N	rebuilt	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "hours.rebuild-month.v1", "operationId": "m2rec-hours-rebuild-month"}	2026-10-01 00:00:00+00	\N	2026-10-25 15:00:10.545+00
\.


--
-- Data for Name: listing_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-01a17391-0eaa-76a8-a603-5c9693467c6d	default	smes.purchase-order.v1.submitted	po-01a17391-0e92-7254-9ad9-0f5938f66b58	purchase-order	2	2026-10-25 14:57:28.746+00	{"to": "submitted", "from": "draft", "actor": "user-seed-admin", "event": "SUBMIT", "flowId": "purchase-order", "reason": "采购订单提交", "objectVersion": 2}
\.


--
-- Data for Name: listing_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_lines (id, tenant_id, sheet_id, work_order_id, kind, line_no, drawing_no, code, name, spec, item_id, required_qty, needed_by, validation_status, candidate_item_id, candidate_item_code, similarity, basis, source, object_version, created_at, updated_at) FROM stdin;
ll-01a17392-60e2-76a0-88fb-5bc926426c98	default	ls-01a17392-60c3-7ecc-8a24-8c7434b49661	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	1	DWG-XL-1	C-XL-1	端盖	规格X	\N	3	2026-11-15 00:00:00+00	unmatched	\N	\N	0	none	excel	1	2026-10-25 14:58:55.331+00	2026-10-25 14:58:55.331+00
ll-01a17392-60e2-7aa3-8293-0f573fd24394	default	ls-01a17392-60c3-7ecc-8a24-8c7434b49661	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	2	DWG-XL-2	C-XL-2	压盖	规格Y	\N	2	2026-11-16 00:00:00+00	unmatched	\N	\N	0	none	excel	1	2026-10-25 14:58:55.332+00	2026-10-25 14:58:55.332+00
\.


--
-- Data for Name: listing_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2rec-purchase-order-submit	default	m2rec-purchase-order-submit	purchase.order.submit.v1	purchase-order	po-01a17391-0e92-7254-9ad9-0f5938f66b58	2026-10-25 14:57:28.722+00
default|m2rec-listing-import-part	default	m2rec-listing-import-part	listing.import.v1	listing-sheet	ls-01a17392-60c3-7ecc-8a24-8c7434b49661	2026-10-25 14:58:55.307+00
default|m2rec-listing-gap-check	default	m2rec-listing-gap-check	gap.check.v1	gap-check	gap-01a17392-61ac-76e0-a5a0-b1b63510af44	2026-10-25 14:58:55.532+00
\.


--
-- Data for Name: listing_sheets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.listing_sheets (id, tenant_id, work_order_id, kind, name, created_at, updated_at) FROM stdin;
ls-01a17392-60c3-7ecc-8a24-8c7434b49661	default	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	part	零件清单（wo-01a1738f-7c86-7723-85a2-95c9da0f3b79）	2026-10-25 14:58:55.299+00	2026-10-25 14:58:55.299+00
\.


--
-- Data for Name: maintenance_activities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_activities (id, tenant_id, seq, kind, resource_ref, plan_id, plan_version, task_id, checkpoint_id, result, actions_done, fault_ref, restored, performed_by, performed_at, note, occurred_at, recorded_by, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
\.


--
-- Data for Name: maintenance_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
\.


--
-- Data for Name: maintenance_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_plans (id, tenant_id, plan_id, name, resource_ref, cycle, checkpoints, upkeep_actions, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: maintenance_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.maintenance_tasks (id, tenant_id, flow_config_id, source, kind, resource_ref, fault_ref, plan_id, plan_version, due_key, due_at, assignee, state, object_version, created_by, created_at, started_at, completed_at, cancelled_at, cancel_reason, source_key) FROM stdin;
\.


--
-- Data for Name: material_validation_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.material_validation_runs (id, tenant_id, issued_by, summary, lines, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
01a17392-60db-759d-9b20-3d3334e31b16	default	user-seed-admin	{"total": 2, "matched": 0, "suspected": 0, "unmatched": 2}	[{"code": "C-XL-1", "name": "端盖", "spec": "规格X", "basis": "none", "lineNo": 1, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}, {"code": "C-XL-2", "name": "压盖", "spec": "规格Y", "basis": "none", "lineNo": 2, "judgment": "unmatched", "similarity": 0, "candidateItemId": null, "candidateItemCode": null}]	1	unaudited	{"contract": "smes.command.v1", "issuedBy": "user-seed-admin", "commandKind": "baseline.material.validate.v1", "operationId": "m2rec-listing-import-part#material"}	\N	2026-10-25 14:58:55.281+00	\N	2026-10-25 14:58:55.324+00
\.


--
-- Data for Name: metric_pack_activations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metric_pack_activations (id, tenant_id, pack_id, pack_version, title, pack, metric_refs, activated_by, activated_at, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: metric_pack_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.metric_pack_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
\.


--
-- Data for Name: nonconformities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.nonconformities (id, tenant_id, inspection_id, flow_config_id, state, object_version, item_id, quantity, reason, disposal, dispose_remark, disposed_by, disposed_at, close_remark, closed_by, closed_at, created_at, updated_at) FROM stdin;
nc-01a1738f-7dc1-7336-8763-2101cc1d73f4	default	insp-01a1738f-7dad-71b1-afc6-2de80920b357	nonconform	closed	3	\N	5	M2 准备链-返工处置	rework	\N	user-seed-admin	2026-10-25 14:55:46.147+00	对账-闭环	user-seed-admin	2026-10-25 14:59:56.924+00	2026-10-25 14:55:46.114+00	2026-10-25 14:59:56.925+00
\.


--
-- Data for Name: outbox_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbox_records (event_id, tenant_id, created_at, attempts, last_attempt_at, next_attempt_at, delivered_at) FROM stdin;
evt-01a1738f-7c97-7ed1-b649-b8c3bb23be68	default	2026-10-25 14:55:45.816+00	0	\N	\N	\N
evt-01a1738f-7ccc-730a-a3f8-5ade24550ec4	default	2026-10-25 14:55:45.868+00	0	\N	\N	\N
evt-01a1738f-7ce3-7196-8a3c-e47e574892b8	default	2026-10-25 14:55:45.891+00	0	\N	\N	\N
evt-01a1738f-7cfa-7178-99c8-fb97fa0665f5	default	2026-10-25 14:55:45.914+00	0	\N	\N	\N
evt-01a1738f-7d08-7355-beb7-d180e9dad6f0	default	2026-10-25 14:55:45.928+00	0	\N	\N	\N
evt-01a1738f-7d14-70ea-ba31-4c3372e75eeb	default	2026-10-25 14:55:45.941+00	0	\N	\N	\N
evt-01a1738f-7d23-795a-a393-a621ab5c71d8	default	2026-10-25 14:55:45.955+00	0	\N	\N	\N
evt-01a1738f-7d2e-7ac7-b1a6-de1ae6570b50	default	2026-10-25 14:55:45.966+00	0	\N	\N	\N
evt-01a1738f-7d3b-7c48-81cd-b7d5e049055e	default	2026-10-25 14:55:45.979+00	0	\N	\N	\N
evt-01a1738f-7d57-79af-b895-fb40b26de49a	default	2026-10-25 14:55:46.007+00	0	\N	\N	\N
evt-01a1738f-7d68-7904-9a83-e471f6c35d77	default	2026-10-25 14:55:46.024+00	0	\N	\N	\N
evt-01a1738f-7d7b-7ad6-a632-c9d5bcac0aaf	default	2026-10-25 14:55:46.043+00	0	\N	\N	\N
evt-14c73511-1046-4ffc-804e-1a93587d1379	default	2026-10-25 14:55:46.067+00	0	\N	\N	\N
evt-01a1738f-7da7-774f-9207-8ac7e663f81c	default	2026-10-25 14:55:46.087+00	0	\N	\N	\N
evt-01a1738f-7db1-7c2d-9845-30f07297862a	default	2026-10-25 14:55:46.097+00	0	\N	\N	\N
evt-01a1738f-7dc4-7e17-8132-ac8c79a7702b	default	2026-10-25 14:55:46.116+00	0	\N	\N	\N
evt-01a1738f-7de6-7d9c-8d5e-c603f3011742	default	2026-10-25 14:55:46.15+00	0	\N	\N	\N
evt-01a1738f-7e02-7627-baa5-aacdfb7bb709	default	2026-10-25 14:55:46.182+00	0	\N	\N	\N
evt-01a1738f-7e02-767f-bc87-ade4a230614f	default	2026-10-25 14:55:46.186+00	0	\N	\N	\N
evt-e254e775-7e39-4361-8fd8-5224a10313b8	default	2026-10-25 14:57:28.113+00	0	\N	\N	\N
evt-01a17391-0dc5-7785-a936-92ba401fbe05	default	2026-10-25 14:57:28.517+00	0	\N	\N	\N
evt-01a17391-0eb3-748a-b448-8fd4f5668537	default	2026-10-25 14:57:28.755+00	0	\N	\N	\N
evt-cc138b9a-44f7-4fca-ae45-8f4359ca0fc0	default	2026-10-25 14:58:55.326+00	0	\N	\N	\N
evt-01a17392-60e6-7603-a66f-36d8c9a54344	default	2026-10-25 14:58:55.334+00	0	\N	\N	\N
evt-01a17392-60e6-7527-86a5-f464222e66f6	default	2026-10-25 14:58:55.337+00	0	\N	\N	\N
evt-01a17392-61b2-71cc-b6a2-cc74cb107c78	default	2026-10-25 14:58:55.538+00	0	\N	\N	\N
evt-01a17392-627d-73b0-bada-7cb31144ff03	default	2026-10-25 14:58:55.741+00	0	\N	\N	\N
evt-01a17392-634a-768e-ad42-d69e733f697d	default	2026-10-25 14:58:55.947+00	0	\N	\N	\N
evt-01a17392-64d9-7cbe-8cc3-acdbf47b9621	default	2026-10-25 14:58:56.345+00	0	\N	\N	\N
evt-01a17393-363f-7c11-badd-d0bb00c837bc	default	2026-10-25 14:59:49.951+00	0	\N	\N	\N
evt-01a17393-4d36-72c6-96a4-704b4cffafc3	default	2026-10-25 14:59:55.83+00	0	\N	\N	\N
evt-01a17393-4d4d-7c31-8845-04ea7226b413	default	2026-10-25 14:59:55.853+00	0	\N	\N	\N
evt-01a17393-4d50-74a8-85c2-7c702b440703	default	2026-10-25 14:59:55.856+00	0	\N	\N	\N
evt-01a17393-4ef6-76a4-978e-7199071086c0	default	2026-10-25 14:59:56.278+00	0	\N	\N	\N
evt-af6fa5de-a90e-415b-afbf-9f708b241659	default	2026-10-25 14:59:56.291+00	0	\N	\N	\N
evt-01a17393-4fd4-792d-9e6a-cc660eefbfaf	default	2026-10-25 14:59:56.5+00	0	\N	\N	\N
evt-91ddfda0-31f7-4f14-a89f-54cba74f4892	default	2026-10-25 14:59:56.514+00	0	\N	\N	\N
evt-01a17393-50b1-75c5-9b40-6959776f963e	default	2026-10-25 14:59:56.724+00	0	\N	\N	\N
evt-01a17393-50b1-7027-8f30-1a876c63708d	default	2026-10-25 14:59:56.726+00	0	\N	\N	\N
evt-01a17393-5181-7ca6-b171-60e064a9191f	default	2026-10-25 14:59:56.929+00	0	\N	\N	\N
evt-01a17393-84f8-7edb-8ff9-2ffbc51b1a97	default	2026-10-25 15:00:10.105+00	0	\N	\N	\N
evt-5495a6ea-2079-408f-a69e-96c536578fe8	default	2026-10-25 15:00:10.548+00	0	\N	\N	\N
evt-5c688e7d-15b6-42e5-a822-1d48198e3613	default	2026-10-25 15:00:10.769+00	0	\N	\N	\N
\.


--
-- Data for Name: outsourcing_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outsourcing_lines (id, tenant_id, dispatch_id, line_no, process_code, drawing_no, supplier_ref, supplier_name, quantity, unit_price_minor, price_source, margin_permyriad, promised_at, source_listing_line_id, object_version, created_at, updated_at) FROM stdin;
osl-01a17392-6344-7391-a2a9-818a0ecf6944	default	dsp-01a17392-6340-7a92-9120-9e22288e778e	1	OP-M2REC-OS	DWG-M2REC-OS-01	SUP-M2REC-OS-01	对账外协一厂	5	30000	manual	\N	2026-12-01 00:00:00+00	\N	1	2026-10-25 14:58:55.944+00	2026-10-25 14:58:55.944+00
\.


--
-- Data for Name: outsourcing_price_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outsourcing_price_rules (id, tenant_id, code, name, process_code, unit_price_minor, margin_permyriad, status, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: parts_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.parts_requests (id, tenant_id, work_order_id, flow_config_id, state, object_version, item_id, quantity, requester, remark, shipment_ref, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pay_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pay_runs (id, tenant_id, person_id, period_key, period_kind, rule_versions, total_quantity, total_amount_minor, line_count, computed_by, computed_at, object_version, supersedes, audit_status, provenance, business_time, created_at) FROM stdin;
\.


--
-- Data for Name: payroll_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_operations (id, tenant_id, operation_id, command_kind) FROM stdin;
\.


--
-- Data for Name: payroll_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_rules (id, tenant_id, rule_id, name, basis, rate_minor, coefficient, scope, object_version, supersedes, audit_status, provenance, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.policies (rule_key, tenant_id, kind, user_id, role, resource, action) FROM stdin;
grant-role|default|user-seed-admin|admin	default	grant-role	user-seed-admin	admin	\N	\N
grant-role|default|user-demo-admin|admin	default	grant-role	user-demo-admin	admin	\N	\N
grant-role|default|user-seed-approver|approver	default	grant-role	user-seed-approver	approver	\N	\N
grant-permission|default|approver|approval|read	default	grant-permission	\N	approver	approval	read
grant-permission|default|approver|approval|write	default	grant-permission	\N	approver	approval	write
grant-permission|default|approver|workbench|read	default	grant-permission	\N	approver	workbench	read
\.


--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.positions (id, tenant_id, code, name, department_ref, active, created_at) FROM stdin;
\.


--
-- Data for Name: process_defs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.process_defs (id, tenant_id, code, name, category, description, status, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_orders (id, tenant_id, work_order_id, flow_config_id, state, object_version, supplier_ref, supplier_name, promised_at, lines, request_ids, buyer, remark, receipt_ref, created_at, updated_at) FROM stdin;
po-01a17391-0e92-7254-9ad9-0f5938f66b58	default	\N	purchase-order	submitted	2	SUP-M2REC-01	对账供应商一厂	2026-12-01 00:00:00+00	[{"itemId": "item-m2rec-01", "lineNo": 1, "quantity": 20, "drawingNo": null, "receivedQty": 0, "unitPriceMinor": 12500}]	[]	\N	\N	\N	2026-10-25 14:57:28.744+00	2026-10-25 14:57:28.751+00
\.


--
-- Data for Name: purchase_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_requests (id, tenant_id, work_order_id, kind, flow_config_id, state, object_version, item_id, quantity, requester, remark, source_type, source_gap_check_id, source_listing_line_id, purchase_order_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchase_returns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.purchase_returns (id, tenant_id, purchase_order_id, flow_config_id, state, object_version, lines, returned_by, remark, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: release_facts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.release_facts (id, tenant_id, inspection_id, phase, kind, item_id, drawing_no, quantity, source_type, source_ref_id, released_at, recorded_at, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
rel-01a1738f-7e02-72c9-9d83-683818e48747	default	insp-01a1738f-7dad-71b1-afc6-2de80920b357	direct@2026-10-25T14:55:46.178Z	self_outsourced	\N	\N	5	\N	\N	2026-10-25 14:55:46.178+00	2026-10-25 14:55:46.179+00	1	recorded	\N	\N	\N	\N
rel-01a17393-50b1-7c31-a97e-887de73a7ac8	default	insp-01a1738f-7d99-7623-8aeb-a12a230ca72c	direct@2026-10-25T14:59:56.721Z	self_outsourced	\N	\N	5	\N	\N	2026-10-25 14:59:56.721+00	2026-10-25 14:59:56.722+00	1	recorded	\N	\N	\N	\N
\.


--
-- Data for Name: report_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_audits (id, tenant_id, report_id, action, actor, reason, changes, created_at) FROM stdin;
rau-01a1738f-7d79-75ae-9b2a-8071ae4b53fd	default	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	verify	user-seed-admin	\N	\N	2026-10-25 14:55:46.041+00
rau-01a17393-4ef4-7634-ad41-32afcf555062	default	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	verify	user-seed-admin	\N	\N	2026-10-25 14:59:56.277+00
rau-01a17393-4fd2-7b6c-9433-6655e77c5f4e	default	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	revoke	user-seed-admin	对账-撤销冲销验证	\N	2026-10-25 14:59:56.498+00
\.


--
-- Data for Name: reporting_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporting_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-36a749e0-4d4e-4724-a6f5-b054b9ee5838	default	smes.work-report.v1.submitted	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	work-report	2	2026-10-25 14:55:46.001+00	{"to": "reported", "from": "pending", "actor": "user-seed-admin", "event": "SUBMIT", "flowId": "work-report", "reason": "零件报工申报", "objectVersion": 2}
2	evt-dcea613c-96da-4cd5-a4ec-40a0484ee2d3	default	smes.work-report.v1.submitted	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	2	2026-10-25 14:55:46.019+00	{"to": "reported", "from": "pending", "actor": "user-seed-admin", "event": "SUBMIT", "flowId": "work-report", "reason": "零件报工申报", "objectVersion": 2}
3	evt-98ce75e7-fc5d-4553-9fc0-5fb2483f507a	default	smes.work-report.v1.verified	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	3	2026-10-25 14:55:46.034+00	{"to": "verified", "from": "reported", "actor": "user-seed-admin", "event": "VERIFY", "flowId": "work-report", "reason": "报工核查通过", "objectVersion": 3}
4	evt-3e4a345e-e22c-49c7-ba79-4046d0b8b723	default	smes.work-report.v1.submitted	wr-01a17393-4d28-7851-ab48-11d3a17b4378	work-report	2	2026-10-25 14:59:55.822+00	{"to": "reported", "from": "pending", "actor": "user-seed-admin", "event": "SUBMIT", "flowId": "work-report", "reason": "零件报工申报", "objectVersion": 2}
5	evt-8996fced-7ef4-4b43-bbdc-62018638e9f2	default	smes.work-report.v1.submitted	wr-01a17393-4d45-7fdc-8414-b96a906e1bd3	work-report	2	2026-10-25 14:59:55.848+00	{"to": "reported", "from": "pending", "actor": "user-seed-admin", "event": "SUBMIT", "flowId": "work-report", "reason": "零件报工申报", "objectVersion": 2}
6	evt-e7b114d0-de98-47c2-b5c9-ce9c442ea535	default	smes.work-report.v1.verified	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	work-report	3	2026-10-25 14:59:56.268+00	{"to": "verified", "from": "reported", "actor": "user-seed-admin", "event": "VERIFY", "flowId": "work-report", "reason": "报工核查通过", "objectVersion": 3}
7	evt-c290d24d-419b-4adf-8b1f-d8bfaef5c8ad	default	smes.work-report.v1.revoked	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	work-report	4	2026-10-25 14:59:56.49+00	{"to": "revoked", "from": "verified", "actor": "user-seed-admin", "event": "REVOKE", "flowId": "work-report", "reason": "对账-撤销冲销验证", "objectVersion": 4}
\.


--
-- Data for Name: reporting_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.reporting_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2prep-report-11	default	m2prep-report-11	report.submit.v1	work-report	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	2026-10-25 14:55:45.987+00
default|m2prep-report-12	default	m2prep-report-12	report.submit.v1	work-report	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	2026-10-25 14:55:46.015+00
default|m2prep-report-13	default	m2prep-report-13	report.verify.v1	work-report	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	2026-10-25 14:55:46.034+00
default|m2rec-report-submit	default	m2rec-report-submit	report.submit.v1	work-report	wr-01a17393-4d28-7851-ab48-11d3a17b4378	2026-10-25 14:59:55.816+00
default|m2rec-report-submit-batch	default	m2rec-report-submit-batch	report.submit-batch.v1	report-batch	wr-01a17393-4d42-7207-bf39-7c63dfe6adfb	2026-10-25 14:59:55.842+00
default|m2rec-report-verify	default	m2rec-report-verify	report.verify.v1	work-report	wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	2026-10-25 14:59:56.268+00
default|m2rec-report-revoke	default	m2rec-report-revoke	report.revoke.v1	work-report	wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	2026-10-25 14:59:56.49+00
\.


--
-- Data for Name: resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.resources (id, tenant_id, code, name, type, active, created_at) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, tenant_id, name, display_name) FROM stdin;
\.


--
-- Data for Name: routings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.routings (id, tenant_id, code, name, steps, status, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, tenant_id, user_id, token_digest, created_at, expires_at, refresh_expires_at, revoked_at) FROM stdin;
6c039c91-5aa6-4537-a1d6-42f8313d50c3	default	user-seed-admin	f5a68ee31b1bd9470e6267f863ae41275307e9b57e20c0840f8825db7ffa67a0	2026-10-25 14:52:43.876+00	2026-10-25 22:52:43.876+00	2026-11-01 14:52:43.876+00	\N
\.


--
-- Data for Name: shipping_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shipping_orders (id, tenant_id, work_order_id, flow_config_id, state, object_version, lines, carrier, tracking_no, executed_by, confirmed_by, confirmed_at, remark, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: standard_times; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.standard_times (id, tenant_id, code, scope, target_code, standard_seconds, preparation_seconds, status, object_version, audit_status, provenance, supersedes, business_time, available_time, created_at) FROM stdin;
\.


--
-- Data for Name: stock_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_accounts (id, tenant_id, item_id, warehouse_id, qty_on_hand, qty_reserved, created_at, updated_at) FROM stdin;
00280f87-9a81-4c07-bb29-28773a29395c	default	item-m2rec-01	wh-01a1738f-7cae-756e-8663-5b0981e502be	10	0	2026-10-25 15:00:10.096899+00	2026-10-25 15:00:10.096899+00
\.


--
-- Data for Name: stock_location_balances; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_location_balances (id, tenant_id, warehouse_id, location_id, item_id, qty, created_at, updated_at) FROM stdin;
daa79df0-950a-4566-9fc9-94091f682be2	default	wh-01a1738f-7cae-756e-8663-5b0981e502be	loc-01a1738f-7cae-7640-9114-c3f6cb52ea6e	item-m2rec-01	10	2026-10-25 15:00:10.101457+00	2026-10-25 15:00:10.101457+00
\.


--
-- Data for Name: stock_movements; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_movements (id, tenant_id, seq, kind, item_id, warehouse_id, location_id, quantity, source_ref_type, source_ref_id, source_key, transfer_id, work_order_id, remark, occurred_at, recorded_by, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
mv-01a17393-84ea-7e6f-94ee-8de554b77269	default	1	production-in	item-m2rec-01	wh-01a1738f-7cae-756e-8663-5b0981e502be	loc-01a1738f-7cae-7640-9114-c3f6cb52ea6e	10	work-order	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	\N	\N	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	\N	2026-10-25 15:00:10.09+00	user-seed-admin	1	recorded	{"actor": "user-seed-admin", "command": "stock.receive.v1", "operationId": "m2rec-inventory-stock-receive"}	\N	\N	\N
\.


--
-- Data for Name: stock_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stock_reservations (id, tenant_id, reservation_key, item_id, warehouse_id, quantity, remaining, status, ref_type, ref_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stocktakes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stocktakes (id, tenant_id, warehouse_id, flow_config_id, state, object_version, lines, opened_by, approved_by, remark, created_at, updated_at) FROM stdin;
st-01a17393-85d1-7928-b15f-84c8935ae378	default	wh-01a1738f-7cae-756e-8663-5b0981e502be	stocktake	counting	2	[{"itemId": "item-m2rec-01", "countedAt": null, "countedBy": null, "systemQty": 10, "countedQty": null}]	user-seed-admin	\N	\N	2026-10-25 15:00:10.325+00	2026-10-25 15:00:10.331+00
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, tenant_id, code, name, active, created_at) FROM stdin;
\.


--
-- Data for Name: todos; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.todos (id, tenant_id, assignee_id, title, source, ref_type, ref_id, status, created_at, due_at) FROM stdin;
01a1738f-7ce7-76eb-a934-a2e4fc799755	default	user-seed-admin	派工待办：零件派工：DWG-M2PREP-1 × OP-10（数量 10）	dispatch	dispatch-order	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	open	2026-10-25 14:55:45.904+00	\N
01a1738f-7d0b-7648-adbb-f598614c9caa	default	user-seed-admin	派工待办：零件派工：DWG-M2PREP-2 × OP-10（数量 10）	dispatch	dispatch-order	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	open	2026-10-25 14:55:45.932+00	\N
01a1738f-7d26-7311-9500-1d0d32408b3d	default	user-seed-admin	派工待办：零件派工：DWG-M2PREP-3 × OP-10（数量 10）	dispatch	dispatch-order	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	open	2026-10-25 14:55:45.958+00	\N
01a1738f-7d3d-75e2-92fb-316bd629fea4	default	user-seed-admin	派工待办：零件派工：DWG-M2PREP-4 × OP-10（数量 10）	dispatch	dispatch-order	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	open	2026-10-25 14:55:45.982+00	\N
01a17391-0c2f-706b-b194-a1857be1b23a	default	user-seed-admin	设备故障待处理：EQ-M2REC-01（已派修）	baseline	baseline-fault-report	fr-01a17391-0c20-7226-a261-ab3e5eec3ffc	open	2026-10-25 14:57:28.112+00	\N
\.


--
-- Data for Name: units; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.units (id, tenant_id, code, name, symbol, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, username, display_name, active, password_hash) FROM stdin;
user-seed-admin	default	admin	种子管理员	t	scrypt$16384$8$1$233a646adc09d53918ead316c2bfa99d$a5271863fda2ab77300a948846a86ee6584645dc4263db147b0ea1c6b187537c96d5b3d5f1b221445ced8d25594eb7612ed4797f6454cd37f035dc16bb0c9362
user-seed-viewer	default	viewer	种子访客（无策略）	t	scrypt$16384$8$1$28b9d1effda89b1cbbd0f9a29c284e48$2e059368aee34c5a45a58dca24677b5125dc4517e0f6d0257ba8720d31f5bb1fc8d99a1a2c2a74f8d91a9f0e720aa1d0817e25e58c16da1f5d60e2819dbfaae7
user-demo-admin	default	demo-admin	演示管理员（Web 登录流）	t	scrypt$16384$8$1$cf36f09583bd9b9634d13a7e1f37f444$7edd50e20bc2b21d54849b12b39e7355565c992a2d281f572acde193e3ae9a806401c0ec6b56ec195e47c337a5b3bd77de4c52027e68da875dfc274b3dfb0163
user-seed-approver	default	approver	种子审批人（approval:read/write）	t	scrypt$16384$8$1$517854c9af723ff5347ba127966e0152$1033fd5d3249257a4b3d8966793cfd2af50d4395f706d89d250582e4a9552b1311b43f6f6830446634a14e0f1ae2b419028f7b63108916b23d9f49283cea53c7
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouse_locations (id, tenant_id, warehouse_id, code, name, created_at) FROM stdin;
loc-01a1738f-7cae-7640-9114-c3f6cb52ea6e	default	wh-01a1738f-7cae-756e-8663-5b0981e502be	PREP	准备链库位	2026-10-25 14:55:45.844+00
loc-01a17391-0f86-7198-b3d8-11f07905627d	default	wh-01a17391-0f86-7636-8240-cf22ff784321	FG	成品区	2026-10-25 14:57:28.974+00
loc-01a17391-0f86-7bcb-a063-3fb9a795df25	default	wh-01a17391-0f86-7636-8240-cf22ff784321	RAW	原料区	2026-10-25 14:57:28.975+00
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.warehouses (id, tenant_id, code, name, default_location_id, created_at, updated_at) FROM stdin;
wh-01a1738f-7cae-756e-8663-5b0981e502be	default	WH-M2PREP-01	准备链主仓	loc-01a1738f-7cae-7640-9114-c3f6cb52ea6e	2026-10-25 14:55:45.843+00	2026-10-25 14:55:45.843+00
wh-01a17391-0f86-7636-8240-cf22ff784321	default	WH-M2REC-01	对账主仓	loc-01a17391-0f86-7198-b3d8-11f07905627d	2026-10-25 14:57:28.973+00	2026-10-25 14:57:28.973+00
\.


--
-- Data for Name: work_order_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_order_attachments (id, tenant_id, work_order_id, name, kind, ref, attached_by, attached_at, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
\.


--
-- Data for Name: work_order_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_order_records (id, tenant_id, work_order_id, object_version, audit_status, provenance, supersedes, business_time, available_time) FROM stdin;
\.


--
-- Data for Name: work_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_orders (id, tenant_id, flow_config_id, state, object_version, customer_ref, project_name, sales_rep, manager, planned_delivery_at, packaging_arrival_at, created_at, updated_at) FROM stdin;
wo-01a17391-0dbd-7513-a7ee-500afc5ad012	default	work-order	not_started	1	\N	M2对账-工作令-01	\N	\N	2026-12-31 00:00:00+00	2026-12-20 00:00:00+00	2026-10-25 14:57:28.513+00	2026-10-25 14:57:28.513+00
wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	default	work-order	in_progress	2	\N	M2对账-准备链A	\N	\N	\N	\N	2026-10-25 14:55:45.813+00	2026-10-25 14:59:49.947+00
\.


--
-- Data for Name: work_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.work_reports (id, tenant_id, dispatch_id, kind, flow_config_id, state, object_version, done_qty, labor_minutes, reporter, work_order_id, drawing_no, operation_code, supersedes, business_time, verified_by, verified_at, revoked_by, revoked_at, revoke_reason, remark, created_at, updated_at) FROM stdin;
wr-01a17393-4d28-7851-ab48-11d3a17b4378	default	dsp-01a1738f-7cbd-763f-98d0-2aa7da17cd00	part	work-report	reported	2	10	90	user-seed-admin	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-1	OP-10	\N	2026-10-25 14:59:55.819+00	\N	\N	\N	\N	\N	\N	2026-10-25 14:59:55.82+00	2026-10-25 14:59:55.826+00
wr-01a17393-4d45-7fdc-8414-b96a906e1bd3	default	dsp-01a1738f-7cf6-715e-8d1c-506f0e4a4369	part	work-report	reported	2	4	120	user-seed-admin	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-2	OP-10	\N	2026-10-25 14:59:55.845+00	\N	\N	\N	\N	\N	\N	2026-10-25 14:59:55.846+00	2026-10-25 14:59:55.85+00
wr-01a1738f-7d43-7c3a-af52-bfbf7fdd8be4	default	dsp-01a1738f-7d11-7a7e-b945-c8506dffa5c4	part	work-report	verified	3	10	90	user-seed-admin	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-3	OP-10	\N	2026-10-25 14:55:45.998+00	user-seed-admin	2026-10-25 14:59:56.273+00	\N	\N	\N	\N	2026-10-25 14:55:45.999+00	2026-10-25 14:59:56.273+00
wr-01a1738f-7d5f-7c71-b80e-2947c24c7a33	default	dsp-01a1738f-7d2b-7c93-8fbf-2fab1f716e26	part	work-report	revoked	4	10	120	user-seed-admin	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	DWG-M2PREP-4	OP-10	\N	2026-10-25 14:55:46.017+00	user-seed-admin	2026-10-25 14:55:46.038+00	user-seed-admin	2026-10-25 14:59:56.495+00	对账-撤销冲销验证	\N	2026-10-25 14:55:46.018+00	2026-10-25 14:59:56.495+00
\.


--
-- Data for Name: workorder_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workorder_events (seq, event_id, tenant_id, event_type, aggregate_id, aggregate_type, aggregate_revision, occurred_at, payload) FROM stdin;
1	evt-e8a67e25-980d-4d38-a480-258dbcbaf715	default	smes.work-order.v1.started	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	work-order	2	2026-10-25 14:59:49.931+00	{"to": "in_progress", "from": "not_started", "actor": "user-seed-admin", "event": "START", "flowId": "work-order", "reason": "流转至 进行中", "objectVersion": 2}
\.


--
-- Data for Name: workorder_operations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workorder_operations (operation_key, tenant_id, operation_id, command, aggregate_type, aggregate_id, occurred_at) FROM stdin;
default|m2prep-workorder-1	default	m2prep-workorder-1	workorder.create.v1	work-order	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	2026-10-25 14:55:45.798+00
default|m2rec-workorder-create	default	m2rec-workorder-create	workorder.create.v1	work-order	wo-01a17391-0dbd-7513-a7ee-500afc5ad012	2026-10-25 14:57:28.509+00
default|m2rec-workorder-kit-refresh	default	m2rec-workorder-kit-refresh	workorder.kit.refresh.v1	kit-check	kc-01a17392-64cf-7503-84ea-39d1dfade432	2026-10-25 14:58:56.335+00
default|m2rec-workorder-transition	default	m2rec-workorder-transition	workorder.transition.v1	work-order	wo-01a1738f-7c86-7723-85a2-95c9da0f3b79	2026-10-25 14:59:49.931+00
\.


--
-- Name: approval_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.approval_events_seq_seq', 1, false);


--
-- Name: cost_entries_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cost_entries_seq_seq', 1, false);


--
-- Name: dispatch_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dispatch_events_seq_seq', 4, true);


--
-- Name: drawing_view_trails_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.drawing_view_trails_seq_seq', 1, false);


--
-- Name: earnings_records_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.earnings_records_seq_seq', 1, false);


--
-- Name: fault_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.fault_events_seq_seq', 1, true);


--
-- Name: gap_checks_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.gap_checks_seq_seq', 1, true);


--
-- Name: inspection_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inspection_events_seq_seq', 5, true);


--
-- Name: inventory_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.inventory_events_seq_seq', 1, true);


--
-- Name: kit_checks_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.kit_checks_seq_seq', 1, true);


--
-- Name: labor_entries_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.labor_entries_seq_seq', 3, true);


--
-- Name: listing_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.listing_events_seq_seq', 1, true);


--
-- Name: maintenance_activities_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.maintenance_activities_seq_seq', 1, false);


--
-- Name: reporting_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.reporting_events_seq_seq', 7, true);


--
-- Name: stock_movements_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.stock_movements_seq_seq', 1, true);


--
-- Name: workorder_events_seq_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.workorder_events_seq_seq', 1, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: approval_cases approval_cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_cases
    ADD CONSTRAINT approval_cases_pkey PRIMARY KEY (id);


--
-- Name: approval_events approval_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_events
    ADD CONSTRAINT approval_events_pkey PRIMARY KEY (seq);


--
-- Name: approval_records approval_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.approval_records
    ADD CONSTRAINT approval_records_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: baseline_command_operations baseline_command_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.baseline_command_operations
    ADD CONSTRAINT baseline_command_operations_pkey PRIMARY KEY (id);


--
-- Name: cost_entries cost_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_entries
    ADD CONSTRAINT cost_entries_pkey PRIMARY KEY (id);


--
-- Name: cost_snapshots cost_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cost_snapshots
    ADD CONSTRAINT cost_snapshots_pkey PRIMARY KEY (id);


--
-- Name: costing_models costing_models_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costing_models
    ADD CONSTRAINT costing_models_pkey PRIMARY KEY (id);


--
-- Name: costing_operations costing_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.costing_operations
    ADD CONSTRAINT costing_operations_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: departments departments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pkey PRIMARY KEY (id);


--
-- Name: dispatch_events dispatch_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_events
    ADD CONSTRAINT dispatch_events_pkey PRIMARY KEY (seq);


--
-- Name: dispatch_operations dispatch_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_operations
    ADD CONSTRAINT dispatch_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: dispatch_orders dispatch_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_orders
    ADD CONSTRAINT dispatch_orders_pkey PRIMARY KEY (id);


--
-- Name: drawing_change_notices drawing_change_notices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drawing_change_notices
    ADD CONSTRAINT drawing_change_notices_pkey PRIMARY KEY (id);


--
-- Name: drawing_operations drawing_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drawing_operations
    ADD CONSTRAINT drawing_operations_pkey PRIMARY KEY (id);


--
-- Name: drawing_revisions drawing_revisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drawing_revisions
    ADD CONSTRAINT drawing_revisions_pkey PRIMARY KEY (id);


--
-- Name: drawing_view_trails drawing_view_trails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.drawing_view_trails
    ADD CONSTRAINT drawing_view_trails_pkey PRIMARY KEY (id);


--
-- Name: earnings_records earnings_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.earnings_records
    ADD CONSTRAINT earnings_records_pkey PRIMARY KEY (id);


--
-- Name: equipment_records equipment_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_records
    ADD CONSTRAINT equipment_records_pkey PRIMARY KEY (id);


--
-- Name: event_records event_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_records
    ADD CONSTRAINT event_records_pkey PRIMARY KEY (event_id);


--
-- Name: fault_events fault_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fault_events
    ADD CONSTRAINT fault_events_pkey PRIMARY KEY (seq);


--
-- Name: fault_reports fault_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.fault_reports
    ADD CONSTRAINT fault_reports_pkey PRIMARY KEY (id);


--
-- Name: gap_checks gap_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.gap_checks
    ADD CONSTRAINT gap_checks_pkey PRIMARY KEY (id);


--
-- Name: hours_operations hours_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hours_operations
    ADD CONSTRAINT hours_operations_pkey PRIMARY KEY (id);


--
-- Name: inspection_events inspection_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_events
    ADD CONSTRAINT inspection_events_pkey PRIMARY KEY (seq);


--
-- Name: inspection_operations inspection_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspection_operations
    ADD CONSTRAINT inspection_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: inspections inspections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inspections
    ADD CONSTRAINT inspections_pkey PRIMARY KEY (id);


--
-- Name: inventory_events inventory_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_events
    ADD CONSTRAINT inventory_events_pkey PRIMARY KEY (seq);


--
-- Name: inventory_operations inventory_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.inventory_operations
    ADD CONSTRAINT inventory_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: items items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT items_pkey PRIMARY KEY (id);


--
-- Name: kit_checks kit_checks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kit_checks
    ADD CONSTRAINT kit_checks_pkey PRIMARY KEY (id);


--
-- Name: labor_entries labor_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_entries
    ADD CONSTRAINT labor_entries_pkey PRIMARY KEY (id);


--
-- Name: labor_ledger_months labor_ledger_months_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.labor_ledger_months
    ADD CONSTRAINT labor_ledger_months_pkey PRIMARY KEY (id);


--
-- Name: listing_events listing_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_events
    ADD CONSTRAINT listing_events_pkey PRIMARY KEY (seq);


--
-- Name: listing_lines listing_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_lines
    ADD CONSTRAINT listing_lines_pkey PRIMARY KEY (id);


--
-- Name: listing_operations listing_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_operations
    ADD CONSTRAINT listing_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: listing_sheets listing_sheets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.listing_sheets
    ADD CONSTRAINT listing_sheets_pkey PRIMARY KEY (id);


--
-- Name: maintenance_activities maintenance_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_activities
    ADD CONSTRAINT maintenance_activities_pkey PRIMARY KEY (id);


--
-- Name: maintenance_operations maintenance_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_operations
    ADD CONSTRAINT maintenance_operations_pkey PRIMARY KEY (id);


--
-- Name: maintenance_plans maintenance_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_plans
    ADD CONSTRAINT maintenance_plans_pkey PRIMARY KEY (id);


--
-- Name: maintenance_tasks maintenance_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.maintenance_tasks
    ADD CONSTRAINT maintenance_tasks_pkey PRIMARY KEY (id);


--
-- Name: material_validation_runs material_validation_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.material_validation_runs
    ADD CONSTRAINT material_validation_runs_pkey PRIMARY KEY (id);


--
-- Name: metric_pack_activations metric_pack_activations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_pack_activations
    ADD CONSTRAINT metric_pack_activations_pkey PRIMARY KEY (id);


--
-- Name: metric_pack_operations metric_pack_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.metric_pack_operations
    ADD CONSTRAINT metric_pack_operations_pkey PRIMARY KEY (id);


--
-- Name: nonconformities nonconformities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.nonconformities
    ADD CONSTRAINT nonconformities_pkey PRIMARY KEY (id);


--
-- Name: outbox_records outbox_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_records
    ADD CONSTRAINT outbox_records_pkey PRIMARY KEY (event_id);


--
-- Name: outsourcing_lines outsourcing_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outsourcing_lines
    ADD CONSTRAINT outsourcing_lines_pkey PRIMARY KEY (id);


--
-- Name: outsourcing_price_rules outsourcing_price_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outsourcing_price_rules
    ADD CONSTRAINT outsourcing_price_rules_pkey PRIMARY KEY (id);


--
-- Name: parts_requests parts_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.parts_requests
    ADD CONSTRAINT parts_requests_pkey PRIMARY KEY (id);


--
-- Name: pay_runs pay_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pay_runs
    ADD CONSTRAINT pay_runs_pkey PRIMARY KEY (id);


--
-- Name: payroll_operations payroll_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_operations
    ADD CONSTRAINT payroll_operations_pkey PRIMARY KEY (id);


--
-- Name: payroll_rules payroll_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_rules
    ADD CONSTRAINT payroll_rules_pkey PRIMARY KEY (id);


--
-- Name: policies policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.policies
    ADD CONSTRAINT policies_pkey PRIMARY KEY (rule_key);


--
-- Name: positions positions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pkey PRIMARY KEY (id);


--
-- Name: process_defs process_defs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_defs
    ADD CONSTRAINT process_defs_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_requests purchase_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_requests
    ADD CONSTRAINT purchase_requests_pkey PRIMARY KEY (id);


--
-- Name: purchase_returns purchase_returns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.purchase_returns
    ADD CONSTRAINT purchase_returns_pkey PRIMARY KEY (id);


--
-- Name: release_facts release_facts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.release_facts
    ADD CONSTRAINT release_facts_pkey PRIMARY KEY (id);


--
-- Name: report_audits report_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_audits
    ADD CONSTRAINT report_audits_pkey PRIMARY KEY (id);


--
-- Name: reporting_events reporting_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_events
    ADD CONSTRAINT reporting_events_pkey PRIMARY KEY (seq);


--
-- Name: reporting_operations reporting_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.reporting_operations
    ADD CONSTRAINT reporting_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: resources resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.resources
    ADD CONSTRAINT resources_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: routings routings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routings
    ADD CONSTRAINT routings_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shipping_orders shipping_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shipping_orders
    ADD CONSTRAINT shipping_orders_pkey PRIMARY KEY (id);


--
-- Name: standard_times standard_times_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standard_times
    ADD CONSTRAINT standard_times_pkey PRIMARY KEY (id);


--
-- Name: stock_accounts stock_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_accounts
    ADD CONSTRAINT stock_accounts_pkey PRIMARY KEY (id);


--
-- Name: stock_location_balances stock_location_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_location_balances
    ADD CONSTRAINT stock_location_balances_pkey PRIMARY KEY (id);


--
-- Name: stock_movements stock_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_movements
    ADD CONSTRAINT stock_movements_pkey PRIMARY KEY (id);


--
-- Name: stock_reservations stock_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stock_reservations
    ADD CONSTRAINT stock_reservations_pkey PRIMARY KEY (id);


--
-- Name: stocktakes stocktakes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stocktakes
    ADD CONSTRAINT stocktakes_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: todos todos_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.todos
    ADD CONSTRAINT todos_pkey PRIMARY KEY (id);


--
-- Name: units units_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.units
    ADD CONSTRAINT units_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (id);


--
-- Name: work_order_attachments work_order_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_attachments
    ADD CONSTRAINT work_order_attachments_pkey PRIMARY KEY (id);


--
-- Name: work_order_records work_order_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_records
    ADD CONSTRAINT work_order_records_pkey PRIMARY KEY (id);


--
-- Name: work_orders work_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_orders
    ADD CONSTRAINT work_orders_pkey PRIMARY KEY (id);


--
-- Name: work_reports work_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_reports
    ADD CONSTRAINT work_reports_pkey PRIMARY KEY (id);


--
-- Name: workorder_events workorder_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workorder_events
    ADD CONSTRAINT workorder_events_pkey PRIMARY KEY (seq);


--
-- Name: workorder_operations workorder_operations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workorder_operations
    ADD CONSTRAINT workorder_operations_pkey PRIMARY KEY (operation_key);


--
-- Name: approval_cases_tenant_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_cases_tenant_id_created_at_idx ON public.approval_cases USING btree (tenant_id, created_at);


--
-- Name: approval_cases_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_cases_tenant_id_state_idx ON public.approval_cases USING btree (tenant_id, state);


--
-- Name: approval_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX approval_events_aggregate_id_aggregate_revision_key ON public.approval_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: approval_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX approval_events_event_id_key ON public.approval_events USING btree (event_id);


--
-- Name: approval_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_events_tenant_id_aggregate_id_seq_idx ON public.approval_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: approval_records_tenant_id_aggregate_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX approval_records_tenant_id_aggregate_id_idx ON public.approval_records USING btree (tenant_id, aggregate_id);


--
-- Name: audit_logs_tenant_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_tenant_id_occurred_at_idx ON public.audit_logs USING btree (tenant_id DESC, occurred_at DESC);


--
-- Name: audit_logs_tenant_id_user_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX audit_logs_tenant_id_user_id_occurred_at_idx ON public.audit_logs USING btree (tenant_id, user_id, occurred_at DESC);


--
-- Name: baseline_command_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX baseline_command_operations_tenant_id_operation_id_key ON public.baseline_command_operations USING btree (tenant_id, operation_id);


--
-- Name: cost_entries_tenant_id_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_entries_tenant_id_category_idx ON public.cost_entries USING btree (tenant_id, category);


--
-- Name: cost_entries_tenant_id_source_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cost_entries_tenant_id_source_key_key ON public.cost_entries USING btree (tenant_id, source_key);


--
-- Name: cost_entries_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_entries_tenant_id_work_order_id_idx ON public.cost_entries USING btree (tenant_id, work_order_id);


--
-- Name: cost_snapshots_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cost_snapshots_tenant_id_supersedes_key ON public.cost_snapshots USING btree (tenant_id, supersedes);


--
-- Name: cost_snapshots_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX cost_snapshots_tenant_id_work_order_id_idx ON public.cost_snapshots USING btree (tenant_id, work_order_id);


--
-- Name: cost_snapshots_tenant_id_work_order_id_model_code_model_version; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX cost_snapshots_tenant_id_work_order_id_model_code_model_version ON public.cost_snapshots USING btree (tenant_id, work_order_id, model_code, model_version, object_version);


--
-- Name: costing_models_tenant_id_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX costing_models_tenant_id_code_idx ON public.costing_models USING btree (tenant_id, code);


--
-- Name: costing_models_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX costing_models_tenant_id_code_object_version_key ON public.costing_models USING btree (tenant_id, code, object_version);


--
-- Name: costing_models_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX costing_models_tenant_id_supersedes_key ON public.costing_models USING btree (tenant_id, supersedes);


--
-- Name: costing_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX costing_operations_tenant_id_operation_id_key ON public.costing_operations USING btree (tenant_id, operation_id);


--
-- Name: customers_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customers_tenant_id_code_key ON public.customers USING btree (tenant_id, code);


--
-- Name: departments_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX departments_tenant_id_code_key ON public.departments USING btree (tenant_id, code);


--
-- Name: departments_tenant_id_parent_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX departments_tenant_id_parent_id_idx ON public.departments USING btree (tenant_id, parent_id);


--
-- Name: dispatch_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dispatch_events_aggregate_id_aggregate_revision_key ON public.dispatch_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: dispatch_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dispatch_events_event_id_key ON public.dispatch_events USING btree (event_id);


--
-- Name: dispatch_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_events_tenant_id_aggregate_id_seq_idx ON public.dispatch_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: dispatch_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_operations_tenant_id_idx ON public.dispatch_operations USING btree (tenant_id);


--
-- Name: dispatch_orders_tenant_id_assignee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_orders_tenant_id_assignee_idx ON public.dispatch_orders USING btree (tenant_id, assignee);


--
-- Name: dispatch_orders_tenant_id_kind_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_orders_tenant_id_kind_state_idx ON public.dispatch_orders USING btree (tenant_id, kind, state);


--
-- Name: dispatch_orders_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_orders_tenant_id_state_idx ON public.dispatch_orders USING btree (tenant_id, state);


--
-- Name: dispatch_orders_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dispatch_orders_tenant_id_work_order_id_idx ON public.dispatch_orders USING btree (tenant_id, work_order_id);


--
-- Name: drawing_change_notices_tenant_id_drawing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX drawing_change_notices_tenant_id_drawing_id_idx ON public.drawing_change_notices USING btree (tenant_id, drawing_id);


--
-- Name: drawing_change_notices_tenant_id_drawing_id_to_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX drawing_change_notices_tenant_id_drawing_id_to_version_key ON public.drawing_change_notices USING btree (tenant_id, drawing_id, to_version);


--
-- Name: drawing_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX drawing_operations_tenant_id_operation_id_key ON public.drawing_operations USING btree (tenant_id, operation_id);


--
-- Name: drawing_revisions_tenant_id_drawing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX drawing_revisions_tenant_id_drawing_id_idx ON public.drawing_revisions USING btree (tenant_id, drawing_id);


--
-- Name: drawing_revisions_tenant_id_drawing_id_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX drawing_revisions_tenant_id_drawing_id_version_key ON public.drawing_revisions USING btree (tenant_id, drawing_id, version);


--
-- Name: drawing_revisions_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX drawing_revisions_tenant_id_supersedes_key ON public.drawing_revisions USING btree (tenant_id, supersedes);


--
-- Name: drawing_view_trails_tenant_id_drawing_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX drawing_view_trails_tenant_id_drawing_id_idx ON public.drawing_view_trails USING btree (tenant_id, drawing_id);


--
-- Name: drawing_view_trails_tenant_id_viewed_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX drawing_view_trails_tenant_id_viewed_by_idx ON public.drawing_view_trails USING btree (tenant_id, viewed_by);


--
-- Name: earnings_records_tenant_id_pay_run_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX earnings_records_tenant_id_pay_run_id_idx ON public.earnings_records USING btree (tenant_id, pay_run_id);


--
-- Name: earnings_records_tenant_id_period_key_person_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX earnings_records_tenant_id_period_key_person_id_idx ON public.earnings_records USING btree (tenant_id, period_key, person_id);


--
-- Name: earnings_records_tenant_id_source_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX earnings_records_tenant_id_source_key_key ON public.earnings_records USING btree (tenant_id, source_key);


--
-- Name: equipment_records_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX equipment_records_id_tenant_id_key ON public.equipment_records USING btree (id, tenant_id);


--
-- Name: equipment_records_tenant_id_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX equipment_records_tenant_id_code_idx ON public.equipment_records USING btree (tenant_id, code);


--
-- Name: equipment_records_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX equipment_records_tenant_id_code_object_version_key ON public.equipment_records USING btree (tenant_id, code, object_version);


--
-- Name: equipment_records_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX equipment_records_tenant_id_supersedes_key ON public.equipment_records USING btree (tenant_id, supersedes);


--
-- Name: event_records_tenant_id_aggregate_id_aggregate_revision_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_records_tenant_id_aggregate_id_aggregate_revision_idx ON public.event_records USING btree (tenant_id, aggregate_id, aggregate_revision);


--
-- Name: event_records_tenant_id_occurred_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX event_records_tenant_id_occurred_at_idx ON public.event_records USING btree (tenant_id, occurred_at);


--
-- Name: fault_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX fault_events_aggregate_id_aggregate_revision_key ON public.fault_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: fault_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX fault_events_event_id_key ON public.fault_events USING btree (event_id);


--
-- Name: fault_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fault_events_tenant_id_aggregate_id_seq_idx ON public.fault_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: fault_reports_tenant_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fault_reports_tenant_id_created_at_idx ON public.fault_reports USING btree (tenant_id, created_at);


--
-- Name: fault_reports_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX fault_reports_tenant_id_state_idx ON public.fault_reports USING btree (tenant_id, state);


--
-- Name: gap_checks_tenant_id_work_order_id_checked_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX gap_checks_tenant_id_work_order_id_checked_at_idx ON public.gap_checks USING btree (tenant_id, work_order_id, checked_at DESC, seq DESC);


--
-- Name: hours_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX hours_operations_tenant_id_operation_id_key ON public.hours_operations USING btree (tenant_id, operation_id);


--
-- Name: inspection_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inspection_events_aggregate_id_aggregate_revision_key ON public.inspection_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: inspection_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inspection_events_event_id_key ON public.inspection_events USING btree (event_id);


--
-- Name: inspection_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_events_tenant_id_aggregate_id_seq_idx ON public.inspection_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: inspection_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspection_operations_tenant_id_idx ON public.inspection_operations USING btree (tenant_id);


--
-- Name: inspections_tenant_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_tenant_id_created_at_idx ON public.inspections USING btree (tenant_id, created_at);


--
-- Name: inspections_tenant_id_kind_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_tenant_id_kind_state_idx ON public.inspections USING btree (tenant_id, kind, state);


--
-- Name: inspections_tenant_id_source_type_source_ref_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inspections_tenant_id_source_type_source_ref_id_key ON public.inspections USING btree (tenant_id, source_type, source_ref_id);


--
-- Name: inspections_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inspections_tenant_id_state_idx ON public.inspections USING btree (tenant_id, state);


--
-- Name: inventory_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_events_aggregate_id_aggregate_revision_key ON public.inventory_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: inventory_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX inventory_events_event_id_key ON public.inventory_events USING btree (event_id);


--
-- Name: inventory_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_events_tenant_id_aggregate_id_seq_idx ON public.inventory_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: inventory_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX inventory_operations_tenant_id_idx ON public.inventory_operations USING btree (tenant_id);


--
-- Name: items_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX items_tenant_id_code_key ON public.items USING btree (tenant_id, code);


--
-- Name: kit_checks_tenant_id_work_order_id_refreshed_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX kit_checks_tenant_id_work_order_id_refreshed_at_idx ON public.kit_checks USING btree (tenant_id, work_order_id, refreshed_at DESC, seq DESC);


--
-- Name: labor_entries_tenant_id_source_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX labor_entries_tenant_id_source_key_key ON public.labor_entries USING btree (tenant_id, source_key);


--
-- Name: labor_entries_tenant_id_source_report_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_entries_tenant_id_source_report_id_idx ON public.labor_entries USING btree (tenant_id, source_report_id);


--
-- Name: labor_entries_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_entries_tenant_id_work_order_id_idx ON public.labor_entries USING btree (tenant_id, work_order_id);


--
-- Name: labor_entries_tenant_id_worker_id_work_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_entries_tenant_id_worker_id_work_date_idx ON public.labor_entries USING btree (tenant_id, worker_id, work_date);


--
-- Name: labor_ledger_months_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX labor_ledger_months_tenant_id_supersedes_key ON public.labor_ledger_months USING btree (tenant_id, supersedes);


--
-- Name: labor_ledger_months_tenant_id_worker_id_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX labor_ledger_months_tenant_id_worker_id_month_idx ON public.labor_ledger_months USING btree (tenant_id, worker_id, month);


--
-- Name: labor_ledger_months_tenant_id_worker_id_month_trade_object_vers; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX labor_ledger_months_tenant_id_worker_id_month_trade_object_vers ON public.labor_ledger_months USING btree (tenant_id, worker_id, month, trade, object_version);


--
-- Name: listing_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX listing_events_aggregate_id_aggregate_revision_key ON public.listing_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: listing_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX listing_events_event_id_key ON public.listing_events USING btree (event_id);


--
-- Name: listing_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX listing_events_tenant_id_aggregate_id_seq_idx ON public.listing_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: listing_lines_tenant_id_sheet_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX listing_lines_tenant_id_sheet_id_idx ON public.listing_lines USING btree (tenant_id, sheet_id);


--
-- Name: listing_lines_tenant_id_sheet_id_line_no_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX listing_lines_tenant_id_sheet_id_line_no_key ON public.listing_lines USING btree (tenant_id, sheet_id, line_no);


--
-- Name: listing_lines_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX listing_lines_tenant_id_work_order_id_idx ON public.listing_lines USING btree (tenant_id, work_order_id);


--
-- Name: listing_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX listing_operations_tenant_id_idx ON public.listing_operations USING btree (tenant_id);


--
-- Name: listing_sheets_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX listing_sheets_tenant_id_work_order_id_idx ON public.listing_sheets USING btree (tenant_id, work_order_id);


--
-- Name: listing_sheets_tenant_id_work_order_id_kind_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX listing_sheets_tenant_id_work_order_id_kind_key ON public.listing_sheets USING btree (tenant_id, work_order_id, kind);


--
-- Name: maintenance_activities_tenant_id_resource_ref_performed_at_seq_; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_activities_tenant_id_resource_ref_performed_at_seq_ ON public.maintenance_activities USING btree (tenant_id, resource_ref, performed_at DESC, seq DESC);


--
-- Name: maintenance_activities_tenant_id_task_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_activities_tenant_id_task_id_idx ON public.maintenance_activities USING btree (tenant_id, task_id);


--
-- Name: maintenance_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX maintenance_operations_tenant_id_operation_id_key ON public.maintenance_operations USING btree (tenant_id, operation_id);


--
-- Name: maintenance_plans_tenant_id_plan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_plans_tenant_id_plan_id_idx ON public.maintenance_plans USING btree (tenant_id, plan_id);


--
-- Name: maintenance_plans_tenant_id_plan_id_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX maintenance_plans_tenant_id_plan_id_object_version_key ON public.maintenance_plans USING btree (tenant_id, plan_id, object_version);


--
-- Name: maintenance_plans_tenant_id_resource_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_plans_tenant_id_resource_ref_idx ON public.maintenance_plans USING btree (tenant_id, resource_ref);


--
-- Name: maintenance_plans_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX maintenance_plans_tenant_id_supersedes_key ON public.maintenance_plans USING btree (tenant_id, supersedes);


--
-- Name: maintenance_tasks_tenant_id_assignee_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_tasks_tenant_id_assignee_idx ON public.maintenance_tasks USING btree (tenant_id, assignee);


--
-- Name: maintenance_tasks_tenant_id_plan_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_tasks_tenant_id_plan_id_idx ON public.maintenance_tasks USING btree (tenant_id, plan_id);


--
-- Name: maintenance_tasks_tenant_id_resource_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_tasks_tenant_id_resource_ref_idx ON public.maintenance_tasks USING btree (tenant_id, resource_ref);


--
-- Name: maintenance_tasks_tenant_id_source_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX maintenance_tasks_tenant_id_source_key_key ON public.maintenance_tasks USING btree (tenant_id, source_key);


--
-- Name: maintenance_tasks_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX maintenance_tasks_tenant_id_state_idx ON public.maintenance_tasks USING btree (tenant_id, state);


--
-- Name: material_validation_runs_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX material_validation_runs_id_tenant_id_key ON public.material_validation_runs USING btree (id, tenant_id);


--
-- Name: material_validation_runs_tenant_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX material_validation_runs_tenant_id_created_at_idx ON public.material_validation_runs USING btree (tenant_id, created_at);


--
-- Name: metric_pack_activations_tenant_id_pack_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX metric_pack_activations_tenant_id_pack_id_idx ON public.metric_pack_activations USING btree (tenant_id, pack_id);


--
-- Name: metric_pack_activations_tenant_id_pack_id_pack_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX metric_pack_activations_tenant_id_pack_id_pack_version_key ON public.metric_pack_activations USING btree (tenant_id, pack_id, pack_version);


--
-- Name: metric_pack_activations_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX metric_pack_activations_tenant_id_supersedes_key ON public.metric_pack_activations USING btree (tenant_id, supersedes);


--
-- Name: metric_pack_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX metric_pack_operations_tenant_id_operation_id_key ON public.metric_pack_operations USING btree (tenant_id, operation_id);


--
-- Name: nonconformities_tenant_id_inspection_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nonconformities_tenant_id_inspection_id_idx ON public.nonconformities USING btree (tenant_id, inspection_id);


--
-- Name: nonconformities_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX nonconformities_tenant_id_state_idx ON public.nonconformities USING btree (tenant_id, state);


--
-- Name: outbox_records_delivered_at_next_attempt_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outbox_records_delivered_at_next_attempt_at_idx ON public.outbox_records USING btree (delivered_at, next_attempt_at);


--
-- Name: outbox_records_pending_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outbox_records_pending_idx ON public.outbox_records USING btree (next_attempt_at) WHERE (delivered_at IS NULL);


--
-- Name: outsourcing_lines_tenant_id_dispatch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outsourcing_lines_tenant_id_dispatch_id_idx ON public.outsourcing_lines USING btree (tenant_id, dispatch_id);


--
-- Name: outsourcing_lines_tenant_id_dispatch_id_line_no_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX outsourcing_lines_tenant_id_dispatch_id_line_no_key ON public.outsourcing_lines USING btree (tenant_id, dispatch_id, line_no);


--
-- Name: outsourcing_lines_tenant_id_supplier_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outsourcing_lines_tenant_id_supplier_ref_idx ON public.outsourcing_lines USING btree (tenant_id, supplier_ref);


--
-- Name: outsourcing_price_rules_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX outsourcing_price_rules_id_tenant_id_key ON public.outsourcing_price_rules USING btree (id, tenant_id);


--
-- Name: outsourcing_price_rules_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX outsourcing_price_rules_tenant_id_code_object_version_key ON public.outsourcing_price_rules USING btree (tenant_id, code, object_version);


--
-- Name: outsourcing_price_rules_tenant_id_process_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outsourcing_price_rules_tenant_id_process_code_idx ON public.outsourcing_price_rules USING btree (tenant_id, process_code);


--
-- Name: outsourcing_price_rules_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX outsourcing_price_rules_tenant_id_supersedes_key ON public.outsourcing_price_rules USING btree (tenant_id, supersedes);


--
-- Name: parts_requests_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parts_requests_tenant_id_state_idx ON public.parts_requests USING btree (tenant_id, state);


--
-- Name: parts_requests_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX parts_requests_tenant_id_work_order_id_idx ON public.parts_requests USING btree (tenant_id, work_order_id);


--
-- Name: pay_runs_tenant_id_period_key_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pay_runs_tenant_id_period_key_idx ON public.pay_runs USING btree (tenant_id, period_key);


--
-- Name: pay_runs_tenant_id_period_key_person_id_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pay_runs_tenant_id_period_key_person_id_object_version_key ON public.pay_runs USING btree (tenant_id, period_key, person_id, object_version);


--
-- Name: pay_runs_tenant_id_person_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pay_runs_tenant_id_person_id_idx ON public.pay_runs USING btree (tenant_id, person_id);


--
-- Name: pay_runs_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX pay_runs_tenant_id_supersedes_key ON public.pay_runs USING btree (tenant_id, supersedes);


--
-- Name: payroll_operations_tenant_id_operation_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payroll_operations_tenant_id_operation_id_key ON public.payroll_operations USING btree (tenant_id, operation_id);


--
-- Name: payroll_rules_tenant_id_rule_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_rules_tenant_id_rule_id_idx ON public.payroll_rules USING btree (tenant_id, rule_id);


--
-- Name: payroll_rules_tenant_id_rule_id_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payroll_rules_tenant_id_rule_id_object_version_key ON public.payroll_rules USING btree (tenant_id, rule_id, object_version);


--
-- Name: payroll_rules_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX payroll_rules_tenant_id_supersedes_key ON public.payroll_rules USING btree (tenant_id, supersedes);


--
-- Name: policies_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX policies_tenant_id_idx ON public.policies USING btree (tenant_id);


--
-- Name: positions_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX positions_tenant_id_code_key ON public.positions USING btree (tenant_id, code);


--
-- Name: positions_tenant_id_department_ref_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX positions_tenant_id_department_ref_idx ON public.positions USING btree (tenant_id, department_ref);


--
-- Name: process_defs_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX process_defs_id_tenant_id_key ON public.process_defs USING btree (id, tenant_id);


--
-- Name: process_defs_tenant_id_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX process_defs_tenant_id_code_idx ON public.process_defs USING btree (tenant_id, code);


--
-- Name: process_defs_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX process_defs_tenant_id_code_object_version_key ON public.process_defs USING btree (tenant_id, code, object_version);


--
-- Name: process_defs_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX process_defs_tenant_id_supersedes_key ON public.process_defs USING btree (tenant_id, supersedes);


--
-- Name: purchase_orders_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_tenant_id_state_idx ON public.purchase_orders USING btree (tenant_id, state);


--
-- Name: purchase_orders_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_orders_tenant_id_work_order_id_idx ON public.purchase_orders USING btree (tenant_id, work_order_id);


--
-- Name: purchase_requests_tenant_id_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_requests_tenant_id_purchase_order_id_idx ON public.purchase_requests USING btree (tenant_id, purchase_order_id);


--
-- Name: purchase_requests_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_requests_tenant_id_state_idx ON public.purchase_requests USING btree (tenant_id, state);


--
-- Name: purchase_requests_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_requests_tenant_id_work_order_id_idx ON public.purchase_requests USING btree (tenant_id, work_order_id);


--
-- Name: purchase_returns_tenant_id_purchase_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX purchase_returns_tenant_id_purchase_order_id_idx ON public.purchase_returns USING btree (tenant_id, purchase_order_id);


--
-- Name: release_facts_tenant_id_inspection_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX release_facts_tenant_id_inspection_id_idx ON public.release_facts USING btree (tenant_id, inspection_id);


--
-- Name: release_facts_tenant_id_inspection_id_phase_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX release_facts_tenant_id_inspection_id_phase_key ON public.release_facts USING btree (tenant_id, inspection_id, phase);


--
-- Name: report_audits_tenant_id_report_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX report_audits_tenant_id_report_id_idx ON public.report_audits USING btree (tenant_id, report_id);


--
-- Name: reporting_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reporting_events_aggregate_id_aggregate_revision_key ON public.reporting_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: reporting_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX reporting_events_event_id_key ON public.reporting_events USING btree (event_id);


--
-- Name: reporting_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reporting_events_tenant_id_aggregate_id_seq_idx ON public.reporting_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: reporting_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX reporting_operations_tenant_id_idx ON public.reporting_operations USING btree (tenant_id);


--
-- Name: resources_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX resources_tenant_id_code_key ON public.resources USING btree (tenant_id, code);


--
-- Name: roles_tenant_id_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX roles_tenant_id_name_key ON public.roles USING btree (tenant_id, name);


--
-- Name: routings_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX routings_id_tenant_id_key ON public.routings USING btree (id, tenant_id);


--
-- Name: routings_tenant_id_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX routings_tenant_id_code_idx ON public.routings USING btree (tenant_id, code);


--
-- Name: routings_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX routings_tenant_id_code_object_version_key ON public.routings USING btree (tenant_id, code, object_version);


--
-- Name: routings_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX routings_tenant_id_supersedes_key ON public.routings USING btree (tenant_id, supersedes);


--
-- Name: sessions_tenant_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sessions_tenant_id_user_id_idx ON public.sessions USING btree (tenant_id, user_id);


--
-- Name: sessions_token_digest_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX sessions_token_digest_key ON public.sessions USING btree (token_digest);


--
-- Name: shipping_orders_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipping_orders_tenant_id_state_idx ON public.shipping_orders USING btree (tenant_id, state);


--
-- Name: shipping_orders_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX shipping_orders_tenant_id_work_order_id_idx ON public.shipping_orders USING btree (tenant_id, work_order_id);


--
-- Name: standard_times_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX standard_times_id_tenant_id_key ON public.standard_times USING btree (id, tenant_id);


--
-- Name: standard_times_tenant_id_code_object_version_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX standard_times_tenant_id_code_object_version_key ON public.standard_times USING btree (tenant_id, code, object_version);


--
-- Name: standard_times_tenant_id_scope_target_code_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX standard_times_tenant_id_scope_target_code_idx ON public.standard_times USING btree (tenant_id, scope, target_code);


--
-- Name: standard_times_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX standard_times_tenant_id_supersedes_key ON public.standard_times USING btree (tenant_id, supersedes);


--
-- Name: stock_accounts_tenant_id_item_id_warehouse_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_accounts_tenant_id_item_id_warehouse_id_key ON public.stock_accounts USING btree (tenant_id, item_id, warehouse_id);


--
-- Name: stock_location_balances_tenant_id_item_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_location_balances_tenant_id_item_id_idx ON public.stock_location_balances USING btree (tenant_id, item_id);


--
-- Name: stock_location_balances_tenant_id_warehouse_id_location_id_item; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_location_balances_tenant_id_warehouse_id_location_id_item ON public.stock_location_balances USING btree (tenant_id, warehouse_id, location_id, item_id);


--
-- Name: stock_movements_tenant_id_item_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_tenant_id_item_id_seq_idx ON public.stock_movements USING btree (tenant_id, item_id, seq);


--
-- Name: stock_movements_tenant_id_occurred_at_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_tenant_id_occurred_at_seq_idx ON public.stock_movements USING btree (tenant_id, occurred_at DESC, seq DESC);


--
-- Name: stock_movements_tenant_id_source_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_movements_tenant_id_source_key_key ON public.stock_movements USING btree (tenant_id, source_key);


--
-- Name: stock_movements_tenant_id_warehouse_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_movements_tenant_id_warehouse_id_seq_idx ON public.stock_movements USING btree (tenant_id, warehouse_id, seq);


--
-- Name: stock_reservations_tenant_id_reservation_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX stock_reservations_tenant_id_reservation_key_key ON public.stock_reservations USING btree (tenant_id, reservation_key);


--
-- Name: stock_reservations_tenant_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stock_reservations_tenant_id_status_idx ON public.stock_reservations USING btree (tenant_id, status);


--
-- Name: stocktakes_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stocktakes_tenant_id_state_idx ON public.stocktakes USING btree (tenant_id, state);


--
-- Name: stocktakes_tenant_id_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX stocktakes_tenant_id_warehouse_id_idx ON public.stocktakes USING btree (tenant_id, warehouse_id);


--
-- Name: suppliers_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX suppliers_tenant_id_code_key ON public.suppliers USING btree (tenant_id, code);


--
-- Name: todos_tenant_id_assignee_id_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX todos_tenant_id_assignee_id_status_idx ON public.todos USING btree (tenant_id, assignee_id, status);


--
-- Name: units_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX units_tenant_id_code_key ON public.units USING btree (tenant_id, code);


--
-- Name: users_tenant_id_username_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_tenant_id_username_key ON public.users USING btree (tenant_id, username);


--
-- Name: warehouse_locations_tenant_id_warehouse_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX warehouse_locations_tenant_id_warehouse_id_code_key ON public.warehouse_locations USING btree (tenant_id, warehouse_id, code);


--
-- Name: warehouse_locations_tenant_id_warehouse_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX warehouse_locations_tenant_id_warehouse_id_idx ON public.warehouse_locations USING btree (tenant_id, warehouse_id);


--
-- Name: warehouses_tenant_id_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX warehouses_tenant_id_code_key ON public.warehouses USING btree (tenant_id, code);


--
-- Name: work_order_attachments_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_attachments_tenant_id_work_order_id_idx ON public.work_order_attachments USING btree (tenant_id, work_order_id);


--
-- Name: work_order_records_id_tenant_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_order_records_id_tenant_id_key ON public.work_order_records USING btree (id, tenant_id);


--
-- Name: work_order_records_tenant_id_supersedes_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX work_order_records_tenant_id_supersedes_key ON public.work_order_records USING btree (tenant_id, supersedes);


--
-- Name: work_order_records_tenant_id_work_order_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_order_records_tenant_id_work_order_id_idx ON public.work_order_records USING btree (tenant_id, work_order_id);


--
-- Name: work_orders_manager_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_manager_idx ON public.work_orders USING btree (tenant_id, manager);


--
-- Name: work_orders_tenant_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_tenant_id_created_at_idx ON public.work_orders USING btree (tenant_id, created_at);


--
-- Name: work_orders_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_orders_tenant_id_state_idx ON public.work_orders USING btree (tenant_id, state);


--
-- Name: work_reports_tenant_id_dispatch_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_dispatch_id_idx ON public.work_reports USING btree (tenant_id, dispatch_id);


--
-- Name: work_reports_tenant_id_drawing_no_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_drawing_no_idx ON public.work_reports USING btree (tenant_id, drawing_no);


--
-- Name: work_reports_tenant_id_kind_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_kind_state_idx ON public.work_reports USING btree (tenant_id, kind, state);


--
-- Name: work_reports_tenant_id_reporter_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_reporter_idx ON public.work_reports USING btree (tenant_id, reporter);


--
-- Name: work_reports_tenant_id_state_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_state_idx ON public.work_reports USING btree (tenant_id, state);


--
-- Name: work_reports_tenant_id_supersedes_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX work_reports_tenant_id_supersedes_idx ON public.work_reports USING btree (tenant_id, supersedes);


--
-- Name: workorder_events_aggregate_id_aggregate_revision_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workorder_events_aggregate_id_aggregate_revision_key ON public.workorder_events USING btree (aggregate_id, aggregate_revision);


--
-- Name: workorder_events_event_id_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX workorder_events_event_id_key ON public.workorder_events USING btree (event_id);


--
-- Name: workorder_events_tenant_id_aggregate_id_seq_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workorder_events_tenant_id_aggregate_id_seq_idx ON public.workorder_events USING btree (tenant_id, aggregate_id, seq);


--
-- Name: workorder_operations_tenant_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX workorder_operations_tenant_id_idx ON public.workorder_operations USING btree (tenant_id);


--
-- Name: approval_events approval_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_events_append_only_guard BEFORE DELETE OR UPDATE ON public.approval_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: approval_records approval_records_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER approval_records_append_only_guard BEFORE DELETE OR UPDATE ON public.approval_records FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: cost_entries cost_entries_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cost_entries_append_only_guard BEFORE DELETE OR UPDATE ON public.cost_entries FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: cost_snapshots cost_snapshots_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER cost_snapshots_append_only_guard BEFORE DELETE OR UPDATE ON public.cost_snapshots FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: costing_models costing_models_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER costing_models_append_only_guard BEFORE DELETE OR UPDATE ON public.costing_models FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: dispatch_events dispatch_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER dispatch_events_append_only_guard BEFORE DELETE OR UPDATE ON public.dispatch_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: drawing_change_notices drawing_change_notices_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER drawing_change_notices_append_only_guard BEFORE DELETE OR UPDATE ON public.drawing_change_notices FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: drawing_revisions drawing_revisions_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER drawing_revisions_append_only_guard BEFORE DELETE OR UPDATE ON public.drawing_revisions FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: drawing_view_trails drawing_view_trails_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER drawing_view_trails_append_only_guard BEFORE DELETE OR UPDATE ON public.drawing_view_trails FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: earnings_records earnings_records_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER earnings_records_append_only_guard BEFORE DELETE OR UPDATE ON public.earnings_records FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: equipment_records equipment_records_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER equipment_records_append_only_guard BEFORE DELETE OR UPDATE ON public.equipment_records FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: event_records event_records_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER event_records_append_only_guard BEFORE DELETE OR UPDATE ON public.event_records FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: fault_events fault_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER fault_events_append_only_guard BEFORE DELETE OR UPDATE ON public.fault_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: gap_checks gap_checks_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER gap_checks_append_only_guard BEFORE DELETE OR UPDATE ON public.gap_checks FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: inspection_events inspection_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inspection_events_append_only_guard BEFORE DELETE OR UPDATE ON public.inspection_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: inventory_events inventory_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER inventory_events_append_only_guard BEFORE DELETE OR UPDATE ON public.inventory_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: kit_checks kit_checks_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER kit_checks_append_only_guard BEFORE DELETE OR UPDATE ON public.kit_checks FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: labor_entries labor_entries_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER labor_entries_append_only_guard BEFORE DELETE OR UPDATE ON public.labor_entries FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: labor_ledger_months labor_ledger_months_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER labor_ledger_months_append_only_guard BEFORE DELETE OR UPDATE ON public.labor_ledger_months FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: listing_events listing_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER listing_events_append_only_guard BEFORE DELETE OR UPDATE ON public.listing_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: maintenance_activities maintenance_activities_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER maintenance_activities_append_only_guard BEFORE DELETE OR UPDATE ON public.maintenance_activities FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: maintenance_plans maintenance_plans_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER maintenance_plans_append_only_guard BEFORE DELETE OR UPDATE ON public.maintenance_plans FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: material_validation_runs material_validation_runs_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER material_validation_runs_append_only_guard BEFORE DELETE OR UPDATE ON public.material_validation_runs FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: metric_pack_activations metric_pack_activations_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER metric_pack_activations_append_only_guard BEFORE DELETE OR UPDATE ON public.metric_pack_activations FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: outsourcing_price_rules outsourcing_price_rules_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER outsourcing_price_rules_append_only_guard BEFORE DELETE OR UPDATE ON public.outsourcing_price_rules FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: pay_runs pay_runs_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER pay_runs_append_only_guard BEFORE DELETE OR UPDATE ON public.pay_runs FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: payroll_rules payroll_rules_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER payroll_rules_append_only_guard BEFORE DELETE OR UPDATE ON public.payroll_rules FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: process_defs process_defs_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER process_defs_append_only_guard BEFORE DELETE OR UPDATE ON public.process_defs FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: release_facts release_facts_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER release_facts_append_only_guard BEFORE DELETE OR UPDATE ON public.release_facts FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: report_audits report_audits_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER report_audits_append_only_guard BEFORE DELETE OR UPDATE ON public.report_audits FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: reporting_events reporting_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER reporting_events_append_only_guard BEFORE DELETE OR UPDATE ON public.reporting_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: routings routings_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER routings_append_only_guard BEFORE DELETE OR UPDATE ON public.routings FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: standard_times standard_times_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER standard_times_append_only_guard BEFORE DELETE OR UPDATE ON public.standard_times FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: stock_movements stock_movements_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER stock_movements_append_only_guard BEFORE DELETE OR UPDATE ON public.stock_movements FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: work_order_attachments work_order_attachments_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER work_order_attachments_append_only_guard BEFORE DELETE OR UPDATE ON public.work_order_attachments FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: work_order_records work_order_records_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER work_order_records_append_only_guard BEFORE DELETE OR UPDATE ON public.work_order_records FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: workorder_events workorder_events_append_only_guard; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER workorder_events_append_only_guard BEFORE DELETE OR UPDATE ON public.workorder_events FOR EACH ROW EXECUTE FUNCTION public.business_store_forbid_mutation();


--
-- Name: equipment_records equipment_records_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment_records
    ADD CONSTRAINT equipment_records_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.equipment_records(id, tenant_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: outbox_records outbox_records_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_records
    ADD CONSTRAINT outbox_records_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.event_records(event_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: outsourcing_price_rules outsourcing_price_rules_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outsourcing_price_rules
    ADD CONSTRAINT outsourcing_price_rules_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.outsourcing_price_rules(id, tenant_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: process_defs process_defs_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.process_defs
    ADD CONSTRAINT process_defs_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.process_defs(id, tenant_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: routings routings_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.routings
    ADD CONSTRAINT routings_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.routings(id, tenant_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: standard_times standard_times_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.standard_times
    ADD CONSTRAINT standard_times_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.standard_times(id, tenant_id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: work_order_records work_order_records_supersedes_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.work_order_records
    ADD CONSTRAINT work_order_records_supersedes_tenant_id_fkey FOREIGN KEY (supersedes, tenant_id) REFERENCES public.work_order_records(id, tenant_id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: approval_cases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_cases ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_events ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.approval_records ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: baseline_command_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.baseline_command_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: cost_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cost_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: cost_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cost_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: costing_models; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.costing_models ENABLE ROW LEVEL SECURITY;

--
-- Name: costing_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.costing_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: customers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: departments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

--
-- Name: dispatch_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dispatch_events ENABLE ROW LEVEL SECURITY;

--
-- Name: dispatch_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dispatch_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: dispatch_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dispatch_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: drawing_change_notices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.drawing_change_notices ENABLE ROW LEVEL SECURITY;

--
-- Name: drawing_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.drawing_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: drawing_revisions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.drawing_revisions ENABLE ROW LEVEL SECURITY;

--
-- Name: drawing_view_trails; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.drawing_view_trails ENABLE ROW LEVEL SECURITY;

--
-- Name: earnings_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.earnings_records ENABLE ROW LEVEL SECURITY;

--
-- Name: equipment_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.equipment_records ENABLE ROW LEVEL SECURITY;

--
-- Name: event_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.event_records ENABLE ROW LEVEL SECURITY;

--
-- Name: fault_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fault_events ENABLE ROW LEVEL SECURITY;

--
-- Name: fault_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.fault_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: gap_checks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.gap_checks ENABLE ROW LEVEL SECURITY;

--
-- Name: hours_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.hours_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: inspection_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inspection_events ENABLE ROW LEVEL SECURITY;

--
-- Name: inspection_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inspection_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: inspections; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inspections ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_events ENABLE ROW LEVEL SECURITY;

--
-- Name: inventory_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.inventory_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;

--
-- Name: kit_checks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kit_checks ENABLE ROW LEVEL SECURITY;

--
-- Name: labor_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.labor_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: labor_ledger_months; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.labor_ledger_months ENABLE ROW LEVEL SECURITY;

--
-- Name: listing_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.listing_events ENABLE ROW LEVEL SECURITY;

--
-- Name: listing_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.listing_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: listing_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.listing_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: listing_sheets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.listing_sheets ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_activities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_activities ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_plans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: maintenance_tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.maintenance_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: material_validation_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.material_validation_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: metric_pack_activations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.metric_pack_activations ENABLE ROW LEVEL SECURITY;

--
-- Name: metric_pack_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.metric_pack_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: nonconformities; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.nonconformities ENABLE ROW LEVEL SECURITY;

--
-- Name: outbox_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.outbox_records ENABLE ROW LEVEL SECURITY;

--
-- Name: outsourcing_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.outsourcing_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: outsourcing_price_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.outsourcing_price_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: parts_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.parts_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: pay_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.pay_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payroll_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: payroll_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payroll_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.policies ENABLE ROW LEVEL SECURITY;

--
-- Name: positions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.positions ENABLE ROW LEVEL SECURITY;

--
-- Name: process_defs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.process_defs ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: purchase_returns; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.purchase_returns ENABLE ROW LEVEL SECURITY;

--
-- Name: release_facts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.release_facts ENABLE ROW LEVEL SECURITY;

--
-- Name: report_audits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.report_audits ENABLE ROW LEVEL SECURITY;

--
-- Name: reporting_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reporting_events ENABLE ROW LEVEL SECURITY;

--
-- Name: reporting_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.reporting_operations ENABLE ROW LEVEL SECURITY;

--
-- Name: resources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.resources ENABLE ROW LEVEL SECURITY;

--
-- Name: roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: routings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.routings ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: shipping_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.shipping_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: standard_times; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.standard_times ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_location_balances; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_location_balances ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_movements; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

--
-- Name: stock_reservations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stock_reservations ENABLE ROW LEVEL SECURITY;

--
-- Name: stocktakes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.stocktakes ENABLE ROW LEVEL SECURITY;

--
-- Name: suppliers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;

--
-- Name: approval_cases tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_cases USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: approval_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: approval_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.approval_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: audit_logs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.audit_logs USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: baseline_command_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.baseline_command_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: cost_entries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.cost_entries USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: cost_snapshots tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.cost_snapshots USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: costing_models tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.costing_models USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: costing_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.costing_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: customers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.customers USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: departments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.departments USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: dispatch_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dispatch_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: dispatch_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dispatch_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: dispatch_orders tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.dispatch_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: drawing_change_notices tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.drawing_change_notices USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: drawing_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.drawing_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: drawing_revisions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.drawing_revisions USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: drawing_view_trails tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.drawing_view_trails USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: earnings_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.earnings_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: equipment_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.equipment_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: event_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.event_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: fault_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.fault_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: fault_reports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.fault_reports USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: gap_checks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.gap_checks USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: hours_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.hours_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inspection_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.inspection_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inspection_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.inspection_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inspections tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.inspections USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inventory_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.inventory_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: inventory_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.inventory_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: items tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.items USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: kit_checks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.kit_checks USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: labor_entries tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.labor_entries USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: labor_ledger_months tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.labor_ledger_months USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: listing_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.listing_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: listing_lines tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.listing_lines USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: listing_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.listing_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: listing_sheets tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.listing_sheets USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: maintenance_activities tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.maintenance_activities USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: maintenance_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.maintenance_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: maintenance_plans tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.maintenance_plans USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: maintenance_tasks tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.maintenance_tasks USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: material_validation_runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.material_validation_runs USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: metric_pack_activations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.metric_pack_activations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: metric_pack_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.metric_pack_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: nonconformities tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.nonconformities USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: outbox_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.outbox_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: outsourcing_lines tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.outsourcing_lines USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: outsourcing_price_rules tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.outsourcing_price_rules USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: parts_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.parts_requests USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: pay_runs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.pay_runs USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: payroll_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.payroll_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: payroll_rules tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.payroll_rules USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: policies tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.policies USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: positions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.positions USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: process_defs tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.process_defs USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: purchase_orders tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.purchase_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: purchase_requests tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.purchase_requests USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: purchase_returns tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.purchase_returns USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: release_facts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.release_facts USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: report_audits tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.report_audits USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: reporting_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.reporting_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: reporting_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.reporting_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: resources tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.resources USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: roles tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.roles USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: routings tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.routings USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: sessions tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.sessions USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: shipping_orders tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.shipping_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: standard_times tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.standard_times USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: stock_accounts tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.stock_accounts USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: stock_location_balances tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.stock_location_balances USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: stock_movements tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.stock_movements USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: stock_reservations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.stock_reservations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: stocktakes tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.stocktakes USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: suppliers tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.suppliers USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: todos tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.todos USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: units tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.units USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: users tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.users USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: warehouse_locations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.warehouse_locations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: warehouses tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.warehouses USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: work_order_attachments tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.work_order_attachments USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: work_order_records tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.work_order_records USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: work_orders tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.work_orders USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: work_reports tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.work_reports USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: workorder_events tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.workorder_events USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: workorder_operations tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation ON public.workorder_operations USING ((tenant_id = current_setting('app.current_tenant'::text, true))) WITH CHECK ((tenant_id = current_setting('app.current_tenant'::text, true)));


--
-- Name: todos; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.todos ENABLE ROW LEVEL SECURITY;

--
-- Name: units; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.units ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: warehouse_locations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warehouse_locations ENABLE ROW LEVEL SECURITY;

--
-- Name: warehouses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;

--
-- Name: work_order_attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_order_attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: work_order_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_order_records ENABLE ROW LEVEL SECURITY;

--
-- Name: work_orders; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_orders ENABLE ROW LEVEL SECURITY;

--
-- Name: work_reports; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.work_reports ENABLE ROW LEVEL SECURITY;

--
-- Name: workorder_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workorder_events ENABLE ROW LEVEL SECURITY;

--
-- Name: workorder_operations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.workorder_operations ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict 65iKXXDdpTlchJRqb024dSjCNbDS13xixoVhD2nCQBVQrgpwZvLhXO9BcjznRZh

